id:oak_wood
name:Oak Wood
break_time:2s
tool:axe
rank:wood
[Texture]
top:oak_wood_up
side:oak_wood
bottom:oak_wood_up
