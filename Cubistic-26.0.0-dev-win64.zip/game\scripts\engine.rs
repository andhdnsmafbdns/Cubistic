use std::sync::Arc;

use bytemuck::{Pod, Zeroable};
use glam::{Mat4, Vec3};
use winit::{
    dpi::LogicalSize,
    event::{DeviceEvent, ElementState, Event, MouseButton, WindowEvent},
    event_loop::{ControlFlow, EventLoop},
    keyboard::{KeyCode, PhysicalKey},
    window::{CursorGrabMode, Fullscreen, Window, WindowBuilder},
};

#[path = "../blocks/mod.rs"]
mod blocks;

const CHUNK: usize = 16;
const CHUNKS: usize = 10;
const WORLD: usize = CHUNK * CHUNKS;
const HEIGHT: usize = 40;
const DEPTH_FORMAT: wgpu::TextureFormat = wgpu::TextureFormat::Depth32Float;
const TEX_ROWS: usize = 16;

const AIR: u8 = 0;
const GRASS: u8 = 1;
const DIRT: u8 = 2;
const STONE: u8 = 3;
const WOOD: u8 = 4;

const SHADER: &str = r#"
struct Uniforms {
    view_proj: mat4x4<f32>,
    light: vec4<f32>,
};
@group(0) @binding(0) var<uniform> u: Uniforms;
@group(0) @binding(1) var tex: texture_2d<f32>;
@group(0) @binding(2) var samp: sampler;

struct VertexIn {
    @location(0) pos: vec3<f32>,
    @location(1) normal: vec3<f32>,
    @location(2) uv: vec2<f32>,
    @location(3) color: vec3<f32>,
};
struct VertexOut {
    @builtin(position) clip: vec4<f32>,
    @location(0) normal: vec3<f32>,
    @location(1) uv: vec2<f32>,
    @location(2) color: vec3<f32>,
};

@vertex
fn vs_main(v: VertexIn) -> VertexOut {
    var out: VertexOut;
    out.clip = u.view_proj * vec4<f32>(v.pos, 1.0);
    out.normal = v.normal;
    out.uv = v.uv;
    out.color = v.color;
    return out;
}

@fragment
fn fs_main(in: VertexOut) -> @location(0) vec4<f32> {
    let tex_c = textureSample(tex, samp, in.uv).rgb;
    let lum = dot(tex_c, vec3<f32>(0.299, 0.587, 0.114));
    let mask = smoothstep(0.45, 0.75, lum);
    let base = mix(tex_c, tex_c * in.color, mask);
    let l = normalize(u.light.xyz);
    let d = max(dot(normalize(in.normal), l), 0.0);
    let lit = 0.55 + 0.7 * d;
    let warm = base * vec3<f32>(1.05, 1.0, 0.88) * lit;
    let shadow_tint = vec3<f32>(0.52, 0.64, 0.98);
    let high_tint = vec3<f32>(1.18, 1.04, 0.80);
    let cine = base * mix(shadow_tint, high_tint, clamp(d, 0.0, 1.0)) * (0.72 + 0.62 * d);
    var outc = base;
    if (u.light.w > 1.5) {
        let lum2 = dot(cine, vec3<f32>(0.299, 0.587, 0.114));
        outc = mix(vec3<f32>(lum2, lum2, lum2), cine, 1.3);
    } else if (u.light.w > 0.5) {
        outc = warm;
    }
    return vec4<f32>(outc, 1.0);
}
"#;

const SKY_SHADER: &str = r#"
struct Uniforms {
    view_proj: mat4x4<f32>,
    light: vec4<f32>,
};
@group(0) @binding(0) var<uniform> u: Uniforms;
@group(0) @binding(1) var tex: texture_2d<f32>;
@group(0) @binding(2) var samp: sampler;

struct V {
    @location(0) pos: vec3<f32>,
    @location(1) normal: vec3<f32>,
    @location(2) uv: vec2<f32>,
    @location(3) color: vec3<f32>,
};
struct O {
    @builtin(position) clip: vec4<f32>,
    @location(0) uv: vec2<f32>,
    @location(1) color: vec3<f32>,
};

@vertex
fn vs_main(v: V) -> O {
    var o: O;
    o.clip = u.view_proj * vec4<f32>(v.pos, 1.0);
    o.uv = v.uv;
    o.color = v.color;
    return o;
}

@fragment
fn fs_main(i: O) -> @location(0) vec4<f32> {
    let c = textureSample(tex, samp, i.uv);
    return vec4<f32>(c.rgb * i.color, c.a);
}
"#;


#[link(name = "winmm")]
extern "system" {
    fn PlaySoundW(name: *const u16, module: isize, flags: u32) -> i32;
}

struct Snd {
    step: Vec<u16>,
    dig: Vec<u16>,
}

fn snd_noise(n: usize, decay: f32, seed: u32) -> Vec<i16> {
    let mut out = Vec::with_capacity(n);
    let mut h = seed;
    let mut prev = 0.0f32;
    for i in 0..n {
        h = h.wrapping_mul(1664525).wrapping_add(1013904223);
        let r = ((h >> 9) as f32 / 8388608.0) - 1.0;
        prev = prev * 0.6 + r * 0.4;
        let t = i as f32 / n as f32;
        let env = (1.0 - t).powf(decay);
        out.push((prev * env * 16000.0) as i16);
    }
    out
}

fn snd_wav(samples: &[i16]) -> Vec<u8> {
    let rate = 22050u32;
    let mut b = Vec::new();
    b.extend_from_slice(b"RIFF");
    b.extend_from_slice(&((36 + samples.len() * 2) as u32).to_le_bytes());
    b.extend_from_slice(b"WAVEfmt ");
    b.extend_from_slice(&16u32.to_le_bytes());
    b.extend_from_slice(&1u16.to_le_bytes());
    b.extend_from_slice(&1u16.to_le_bytes());
    b.extend_from_slice(&rate.to_le_bytes());
    b.extend_from_slice(&(rate * 2).to_le_bytes());
    b.extend_from_slice(&2u16.to_le_bytes());
    b.extend_from_slice(&16u16.to_le_bytes());
    b.extend_from_slice(b"data");
    b.extend_from_slice(&((samples.len() * 2) as u32).to_le_bytes());
    for s in samples {
        b.extend_from_slice(&s.to_le_bytes());
    }
    b
}

impl Snd {
    fn new() -> Snd {
        let base = blocks::candidate_roots()
            .into_iter()
            .find(|p| p.is_dir())
            .unwrap_or_else(|| std::path::PathBuf::from("."));
        let dir = base.join("sounds");
        let _ = std::fs::create_dir_all(&dir);
        let step_p = dir.join("step.wav");
        let dig_p = dir.join("dig.wav");
        if !step_p.is_file() {
            let s = snd_noise(1400, 2.6, 7);
            let _ = std::fs::write(&step_p, snd_wav(&s));
        }
        if !dig_p.is_file() {
            let s = snd_noise(2600, 1.7, 91);
            let _ = std::fs::write(&dig_p, snd_wav(&s));
        }
        Snd {
            step: step_p.to_string_lossy().encode_utf16().chain(std::iter::once(0)).collect(),
            dig: dig_p.to_string_lossy().encode_utf16().chain(std::iter::once(0)).collect(),
        }
    }

    fn play(&self, path: &[u16]) {
        unsafe {
            PlaySoundW(path.as_ptr(), 0, 0x00020000 | 0x0001 | 0x0002);
        }
    }
}

#[repr(C)]
#[derive(Copy, Clone, Pod, Zeroable)]
struct Vertex {
    pos: [f32; 3],
    normal: [f32; 3],
    uv: [f32; 2],
    color: [f32; 3],
}

#[repr(C)]
#[derive(Copy, Clone, Pod, Zeroable)]
struct Uniforms {
    view_proj: [[f32; 4]; 4],
    light: [f32; 4],
}

struct ChunkMesh {
    buffer: wgpu::Buffer,
    count: u32,
    center: Vec3,
}

struct Camera {
    pos: Vec3,
    yaw: f32,
    pitch: f32,
    vel: Vec3,
}


const HUD_SHADER: &str = r#"
struct V { @location(0) pos: vec2<f32>, @location(1) uv: vec2<f32> };
struct O { @builtin(position) clip: vec4<f32>, @location(0) uv: vec2<f32> };
@group(0) @binding(0) var tex: texture_2d<f32>;
@group(0) @binding(1) var samp: sampler;

@vertex
fn vs_main(v: V) -> O {
    var o: O;
    o.clip = vec4<f32>(v.pos, 0.0, 1.0);
    o.uv = v.uv;
    return o;
}

@fragment
fn fs_main(i: O) -> @location(0) vec4<f32> {
    let c = textureSample(tex, samp, i.uv);
    return c;
}
"#;

#[repr(C)]
#[derive(Copy, Clone, Pod, Zeroable)]
struct HudVertex {
    pos: [f32; 2],
    uv: [f32; 2],
}

struct Tip {
    bind: wgpu::BindGroup,
    buffer: wgpu::Buffer,
    texture: wgpu::Texture,
    w: u32,
    h: u32,
    name: String,
}

struct Hud {
    bind: wgpu::BindGroup,
    pipeline: wgpu::RenderPipeline,
    buffer: wgpu::Buffer,
    texture: wgpu::Texture,
    w: u32,
    h: u32,
}

fn rasterize_text(lines: &[String], font: &fontdue::Font, w: usize, h: usize) -> Vec<u8> {
    let mut buf = vec![0u8; w * h * 4];
    let px = 22.0f32;
    let mut baseline = 26.0f32;

    for line in lines {
        let mut x = 8.0f32;
        for ch in line.chars() {
            let (m, bitmap) = font.rasterize(ch, px);
            for by in 0..m.height {
                for bx in 0..m.width {
                    let cov = bitmap[by * m.width + bx];
                    if cov == 0 {
                        continue;
                    }
                    let gx = x + bx as f32 + m.xmin as f32;
                    let gy = baseline - (m.height as f32 - by as f32) - m.ymin as f32 + 4.0;
                    let ix = gx as i32;
                    let iy = gy as i32;
                    if ix < 0 || iy < 0 || ix as usize >= w || iy as usize >= h {
                        continue;
                    }
                    let o = ((iy as usize * w) + ix as usize) * 4;
                    let a = cov as u16;
                    let old = buf[o + 3] as u16;
                    let na = (a + old * (255 - a) / 255).min(255) as u8;
                    buf[o] = 255;
                    buf[o + 1] = 255;
                    buf[o + 2] = 255;
                    buf[o + 3] = na;
                }
            }
            x += m.advance_width;
        }
        baseline += px + 6.0;
    }
    buf
}

fn make_hud_texture(
    device: &wgpu::Device,
    queue: &wgpu::Queue,
    data: &[u8],
    w: u32,
    h: u32,
) -> wgpu::Texture {
    let texture = device.create_texture(&wgpu::TextureDescriptor {
        label: Some("hud"),
        size: wgpu::Extent3d { width: w, height: h, depth_or_array_layers: 1 },
        mip_level_count: 1,
        sample_count: 1,
        dimension: wgpu::TextureDimension::D2,
        format: wgpu::TextureFormat::Rgba8UnormSrgb,
        usage: wgpu::TextureUsages::TEXTURE_BINDING | wgpu::TextureUsages::COPY_DST,
        view_formats: &[],
    });
    queue.write_texture(
        wgpu::ImageCopyTexture {
            texture: &texture,
            mip_level: 0,
            origin: wgpu::Origin3d::ZERO,
            aspect: wgpu::TextureAspect::All,
        },
        data,
        wgpu::ImageDataLayout {
            offset: 0,
            bytes_per_row: Some(4 * w),
            rows_per_image: Some(h),
        },
        wgpu::Extent3d { width: w, height: h, depth_or_array_layers: 1 },
    );
    texture
}

fn hud_quad(w: u32, h: u32, tw: f32, th: f32) -> [HudVertex; 6] {
    let sx = 2.0 / w as f32;
    let sy = 2.0 / h as f32;
    let x1 = -1.0 + tw * sx;
    let y1 = 1.0 - th * sy;
    let p = |x: f32, y: f32, u: f32, v: f32| HudVertex { pos: [x, y], uv: [u, v] };
    [
        p(-1.0, 1.0, 0.0, 0.0),
        p(x1, 1.0, 1.0, 0.0),
        p(x1, y1, 1.0, 1.0),
        p(-1.0, 1.0, 0.0, 0.0),
        p(x1, y1, 1.0, 1.0),
        p(-1.0, y1, 0.0, 1.0),
    ]
}

fn hud_quad_at(x: f32, y: f32, tw: f32, th: f32, w: u32, h: u32) -> [HudVertex; 6] {
    let sx = 2.0 / w as f32;
    let sy = 2.0 / h as f32;
    let x0 = -1.0 + x * sx;
    let y0 = 1.0 - y * sy;
    let x1 = x0 + tw * sx;
    let y1 = y0 - th * sy;
    let p = |x: f32, y: f32, u: f32, v: f32| HudVertex { pos: [x, y], uv: [u, v] };
    [
        p(x0, y0, 0.0, 0.0),
        p(x1, y0, 1.0, 0.0),
        p(x1, y1, 1.0, 1.0),
        p(x0, y0, 0.0, 0.0),
        p(x1, y1, 1.0, 1.0),
        p(x0, y1, 0.0, 1.0),
    ]
}

fn create_hud_pipeline(
    device: &wgpu::Device,
    bgl: &wgpu::BindGroupLayout,
    format: wgpu::TextureFormat,
) -> wgpu::RenderPipeline {
    let shader = device.create_shader_module(wgpu::ShaderModuleDescriptor {
        label: Some("hud shader"),
        source: wgpu::ShaderSource::Wgsl(shader_src("hud", HUD_SHADER).into()),
    });
    let layout = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
        label: Some("hud layout"),
        bind_group_layouts: &[bgl],
        push_constant_ranges: &[],
    });
    device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
        label: Some("hud pipeline"),
        layout: Some(&layout),
        vertex: wgpu::VertexState {
            module: &shader,
            entry_point: "vs_main",
            buffers: &[wgpu::VertexBufferLayout {
                array_stride: std::mem::size_of::<HudVertex>() as u64,
                step_mode: wgpu::VertexStepMode::Vertex,
                attributes: &wgpu::vertex_attr_array![0 => Float32x2, 1 => Float32x2],
            }],
            compilation_options: Default::default(),
        },
        fragment: Some(wgpu::FragmentState {
            module: &shader,
            entry_point: "fs_main",
            targets: &[Some(wgpu::ColorTargetState {
                format,
                blend: Some(wgpu::BlendState::ALPHA_BLENDING),
                write_mask: wgpu::ColorWrites::ALL,
            })],
            compilation_options: Default::default(),
        }),
        primitive: wgpu::PrimitiveState::default(),
        depth_stencil: None,
        multisample: wgpu::MultisampleState::default(),
        multiview: None,
    })
}


const UI_SHADER: &str = r#"
struct V {
    @location(0) pos: vec2<f32>,
    @location(1) uv: vec2<f32>,
    @location(2) color: vec4<f32>,
};
struct O {
    @builtin(position) clip: vec4<f32>,
    @location(0) uv: vec2<f32>,
    @location(1) color: vec4<f32>,
};
@group(0) @binding(0) var tex: texture_2d<f32>;
@group(0) @binding(1) var samp: sampler;

@vertex
fn vs_main(v: V) -> O {
    var o: O;
    o.clip = vec4<f32>(v.pos, 0.0, 1.0);
    o.uv = v.uv;
    o.color = v.color;
    return o;
}

@fragment
fn fs_main(i: O) -> @location(0) vec4<f32> {
    let c = textureSample(tex, samp, i.uv);
    return vec4<f32>(c.rgb * i.color.rgb, c.a * i.color.a);
}
"#;

#[repr(C)]
#[derive(Copy, Clone, Pod, Zeroable)]
struct UiVertex {
    pos: [f32; 2],
    uv: [f32; 2],
    color: [f32; 4],
}

fn ui_rect(out: &mut Vec<UiVertex>, x: f32, y: f32, w: f32, h: f32, screen: (f32, f32), color: [f32; 4]) {
    let sx = 2.0 / screen.0;
    let sy = 2.0 / screen.1;
    let x0 = -1.0 + x * sx;
    let x1 = -1.0 + (x + w) * sx;
    let y0 = 1.0 - y * sy;
    let y1 = 1.0 - (y + h) * sy;
    let uv = [0.5f32, 0.5f32];
    let p = |px: f32, py: f32| UiVertex { pos: [px, py], uv, color };
    out.push(p(x0, y0));
    out.push(p(x1, y0));
    out.push(p(x1, y1));
    out.push(p(x0, y0));
    out.push(p(x1, y1));
    out.push(p(x0, y1));
}

fn ui_quad_tex(out: &mut Vec<UiVertex>, x: f32, y: f32, w: f32, h: f32, screen: (f32, f32), color: [f32; 4]) {
    let sx = 2.0 / screen.0;
    let sy = 2.0 / screen.1;
    let x0 = -1.0 + x * sx;
    let x1 = -1.0 + (x + w) * sx;
    let y0 = 1.0 - y * sy;
    let y1 = 1.0 - (y + h) * sy;
    let p = |px: f32, py: f32, u: f32, v: f32| UiVertex { pos: [px, py], uv: [u, v], color };
    out.push(p(x0, y0, 0.0, 0.0));
    out.push(p(x1, y0, 1.0, 0.0));
    out.push(p(x1, y1, 1.0, 1.0));
    out.push(p(x0, y0, 0.0, 0.0));
    out.push(p(x1, y1, 1.0, 1.0));
    out.push(p(x0, y1, 0.0, 1.0));
}


fn ui_quad4(out: &mut Vec<UiVertex>, pts: [[f32; 2]; 4], screen: (f32, f32), color: [f32; 4]) {
    let sx = 2.0 / screen.0;
    let sy = 2.0 / screen.1;
    let conv = |p: [f32; 2]| UiVertex {
        pos: [-1.0 + p[0] * sx, 1.0 - p[1] * sy],
        uv: [0.5, 0.5],
        color,
    };
    let a = conv(pts[0]);
    let b = conv(pts[1]);
    let c = conv(pts[2]);
    let d = conv(pts[3]);
    out.push(a);
    out.push(b);
    out.push(c);
    out.push(a);
    out.push(c);
    out.push(d);
}

fn ui_quad4_uv(
    out: &mut Vec<UiVertex>,
    pts: [[f32; 2]; 4],
    uv: [[f32; 2]; 4],
    screen: (f32, f32),
    color: [f32; 4],
) {
    let sx = 2.0 / screen.0;
    let sy = 2.0 / screen.1;
    let conv = |p: [f32; 2], t: [f32; 2]| UiVertex {
        pos: [-1.0 + p[0] * sx, 1.0 - p[1] * sy],
        uv: t,
        color,
    };
    let a = conv(pts[0], uv[0]);
    let b = conv(pts[1], uv[1]);
    let c = conv(pts[2], uv[2]);
    let d = conv(pts[3], uv[3]);
    out.push(a);
    out.push(b);
    out.push(c);
    out.push(a);
    out.push(c);
    out.push(d);
}

fn ui_flat_icon(
    out: &mut Vec<UiVertex>,
    cx: f32,
    cy: f32,
    size: f32,
    screen: (f32, f32),
    top_row: u8,
    side_row: u8,
    tint: [f32; 3],
) {
    let rows = TEX_ROWS as f32;
    let s = size * 0.5;
    let cap = size * 0.34;
    let x0 = cx - s;
    let y0 = cy - s - cap * 0.2;
    let v0t = top_row as f32 / rows;
    let v1t = (top_row as f32 + 1.0) / rows;
    let v0s = side_row as f32 / rows;
    let v1s = (side_row as f32 + 1.0) / rows;

    let ang: f32 = -0.7853982;
    let (sa, ca) = (ang.sin(), ang.cos());
    let rot = |px: f32, py: f32| -> [f32; 2] {
        let dx = px - cx;
        let dy = py - cy;
        [cx + dx * ca - dy * sa, cy + dx * sa + dy * ca]
    };

    ui_quad4_uv(
        out,
        [
            rot(x0, y0),
            rot(x0 + size, y0),
            rot(x0 + size, y0 + cap),
            rot(x0, y0 + cap),
        ],
        [[0.0, v0t], [1.0, v0t], [1.0, v1t], [0.0, v1t]],
        screen,
        [tint[0], tint[1], tint[2], 1.0],
    );

    ui_quad4_uv(
        out,
        [
            rot(x0, y0 + cap),
            rot(x0 + size, y0 + cap),
            rot(x0 + size, y0 + cap + size),
            rot(x0, y0 + cap + size),
        ],
        [[0.0, v0s], [1.0, v0s], [1.0, v1s], [0.0, v1s]],
        screen,
        [tint[0] * 0.96, tint[1] * 0.96, tint[2] * 0.96, 1.0],
    );
}

fn ui_iso_cube(
    out: &mut Vec<UiVertex>,
    cx: f32,
    cy: f32,
    size: f32,
    screen: (f32, f32),
    top_row: u8,
    side_row: u8,
    tint: [f32; 3],
) {
    let w = size;
    let h = size * 0.5;
    let sh = size;
    let oy = cy - sh * 0.5;

    let top = [
        [cx, oy - h],
        [cx + w, oy],
        [cx, oy + h],
        [cx - w, oy],
    ];
    let left = [
        [cx - w, oy],
        [cx, oy + h],
        [cx, oy + h + sh],
        [cx - w, oy + sh],
    ];
    let right = [
        [cx, oy + h],
        [cx + w, oy],
        [cx + w, oy + sh],
        [cx, oy + h + sh],
    ];

    let rows = TEX_ROWS as f32;
    let v0t = top_row as f32 / rows;
    let v1t = (top_row as f32 + 1.0) / rows;
    let v0s = side_row as f32 / rows;
    let v1s = (side_row as f32 + 1.0) / rows;

    let uv_top = [[0.0, v0t], [1.0, v0t], [1.0, v1t], [0.0, v1t]];
    let uv_side = [[0.0, v0s], [1.0, v0s], [1.0, v1s], [0.0, v1s]];

    ui_quad4_uv(out, top, uv_top, screen, [tint[0], tint[1], tint[2], 1.0]);
    ui_quad4_uv(out, left, uv_side, screen, [tint[0] * 0.74, tint[1] * 0.74, tint[2] * 0.74, 1.0]);
    ui_quad4_uv(out, right, uv_side, screen, [tint[0] * 0.55, tint[1] * 0.55, tint[2] * 0.55, 1.0]);
}

fn create_ui_pipeline(
    device: &wgpu::Device,
    bgl: &wgpu::BindGroupLayout,
    format: wgpu::TextureFormat,
) -> wgpu::RenderPipeline {
    let shader = device.create_shader_module(wgpu::ShaderModuleDescriptor {
        label: Some("ui shader"),
        source: wgpu::ShaderSource::Wgsl(shader_src("ui", UI_SHADER).into()),
    });
    let layout = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
        label: Some("ui layout"),
        bind_group_layouts: &[bgl],
        push_constant_ranges: &[],
    });
    device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
        label: Some("ui pipeline"),
        layout: Some(&layout),
        vertex: wgpu::VertexState {
            module: &shader,
            entry_point: "vs_main",
            buffers: &[wgpu::VertexBufferLayout {
                array_stride: std::mem::size_of::<UiVertex>() as u64,
                step_mode: wgpu::VertexStepMode::Vertex,
                attributes: &wgpu::vertex_attr_array![0 => Float32x2, 1 => Float32x2, 2 => Float32x4],
            }],
            compilation_options: Default::default(),
        },
        fragment: Some(wgpu::FragmentState {
            module: &shader,
            entry_point: "fs_main",
            targets: &[Some(wgpu::ColorTargetState {
                format,
                blend: Some(wgpu::BlendState::ALPHA_BLENDING),
                write_mask: wgpu::ColorWrites::ALL,
            })],
            compilation_options: Default::default(),
        }),
        primitive: wgpu::PrimitiveState::default(),
        depth_stencil: None,
        multisample: wgpu::MultisampleState::default(),
        multiview: None,
    })
}

fn hash2(x: i32, z: i32) -> f32 {
    let mut h = (x.wrapping_mul(374761393) ^ z.wrapping_mul(668265263)) as u32;
    h = (h ^ (h >> 13)).wrapping_mul(1274126177);
    ((h ^ (h >> 16)) & 0xffff) as f32 / 65535.0
}

fn value_noise(x: f32, z: f32) -> f32 {
    let x0 = x.floor() as i32;
    let z0 = z.floor() as i32;
    let fx = x - x0 as f32;
    let fz = z - z0 as f32;
    let sx = fx * fx * (3.0 - 2.0 * fx);
    let sz = fz * fz * (3.0 - 2.0 * fz);

    let a = hash2(x0, z0);
    let b = hash2(x0 + 1, z0);
    let c = hash2(x0, z0 + 1);
    let d = hash2(x0 + 1, z0 + 1);

    let top = a + (b - a) * sx;
    let bottom = c + (d - c) * sx;
    top + (bottom - top) * sz
}

fn terrain_height(x: usize, z: usize, seed: i32) -> usize {
    let s = (seed.rem_euclid(997)) as f32;
    let fx = x as f32 + s * 7.1;
    let fz = z as f32 + s * 4.3;
    let n = 0.65 * value_noise(fx / 22.0, fz / 22.0) + 0.35 * value_noise(fx / 7.0, fz / 7.0);
    let h = 4.0 + n * 15.0 + (value_noise(fx / 40.0, fz / 40.0) - 0.5) * 6.0;
    (h as usize).clamp(2, HEIGHT - 12)
}

fn idx(x: usize, y: usize, z: usize) -> usize {
    (y * WORLD + z) * WORLD + x
}

fn build_world(seed: i32) -> Vec<u8> {
    let mut blocks = vec![AIR; WORLD * WORLD * HEIGHT];

    for z in 0..WORLD {
        for x in 0..WORLD {
            let h = terrain_height(x, z, seed);
            for y in 0..h {
                let b = if y + 1 == h {
                    GRASS
                } else if y + 4 >= h {
                    DIRT
                } else {
                    STONE
                };
                blocks[idx(x, y, z)] = b;
            }
        }
    }

    let leaves_id = ["leaves", "oak_leaves", "leaf", "tree_leaves"]
        .iter()
        .find_map(|k| blocks::find_key(k).map(|d| d.id))
        .unwrap_or(0);
    let mut tz = 4usize;
    while tz + 5 < WORLD {
        let mut tx = 4usize;
        while tx + 5 < WORLD {
            let jx = (hash2(tx as i32 + seed * 3, tz as i32 + 11) * 2.0) as usize;
            let jz = (hash2(tx as i32 + 17, tz as i32 + seed * 7) * 2.0) as usize;
            let x = tx + jx;
            let z = tz + jz;
            let h = terrain_height(x, z, seed);
            if h + 9 < HEIGHT && h > 0 && blocks[idx(x, h - 1, z)] != AIR {
                for k in 0..5usize {
                    blocks[idx(x, h + k, z)] = WOOD;
                }
                if leaves_id != 0 {
                    let top = h + 4;
                    for dy in 0..3usize {
                        let r: i32 = if dy == 2 { 1 } else { 2 };
                        for dx in -r..=r {
                            for dz in -r..=r {
                                if dy < 2 && dx.abs() == 2 && dz.abs() == 2 {
                                    continue;
                                }
                                let bx = x as i32 + dx;
                                let bz = z as i32 + dz;
                                let by = top + dy;
                                if by >= HEIGHT || bx <= 0 || bz <= 0 {
                                    continue;
                                }
                                if bx as usize >= WORLD - 1 || bz as usize >= WORLD - 1 {
                                    continue;
                                }
                                let i = idx(bx as usize, by, bz as usize);
                                if blocks[i] == AIR {
                                    blocks[i] = leaves_id;
                                }
                            }
                        }
                    }
                    for dx in -1i32..=1 {
                        for dz in -1i32..=1 {
                            let by = top + 3;
                            if by < HEIGHT {
                                let bx = x as i32 + dx;
                                let bz = z as i32 + dz;
                                if bx > 0 && bz > 0 && (bx as usize) < WORLD - 1 && (bz as usize) < WORLD - 1 {
                                    let i = idx(bx as usize, by, bz as usize);
                                    if blocks[i] == AIR {
                                        blocks[i] = leaves_id;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            tx += 7;
        }
        tz += 7;
    }

    blocks
}

fn block_at(blocks: &[u8], x: i32, y: i32, z: i32) -> u8 {
    if x < 0 || z < 0 || y < 0 || x >= WORLD as i32 || z >= WORLD as i32 || y >= HEIGHT as i32 {
        return STONE;
    }
    blocks[idx(x as usize, y as usize, z as usize)]
}

fn face_row(block: u8, face: usize) -> f32 {
    match blocks::find(block) {
        Some(d) => match face {
            0 => d.tex_south as f32,
            1 => d.tex_north as f32,
            2 => d.tex_east as f32,
            3 => d.tex_west as f32,
            4 => d.tex_top as f32,
            _ => d.tex_bottom as f32,
        },
        None => 3.0,
    }}

const FACES: [([f32; 3], [[f32; 3]; 4]); 6] = [
    ([0.0, 0.0, 1.0], [[0.0, 0.0, 1.0], [1.0, 0.0, 1.0], [1.0, 1.0, 1.0], [0.0, 1.0, 1.0]]),
    ([0.0, 0.0, -1.0], [[1.0, 0.0, 0.0], [0.0, 0.0, 0.0], [0.0, 1.0, 0.0], [1.0, 1.0, 0.0]]),
    ([1.0, 0.0, 0.0], [[1.0, 0.0, 1.0], [1.0, 0.0, 0.0], [1.0, 1.0, 0.0], [1.0, 1.0, 1.0]]),
    ([-1.0, 0.0, 0.0], [[0.0, 0.0, 0.0], [0.0, 0.0, 1.0], [0.0, 1.0, 1.0], [0.0, 1.0, 0.0]]),
    ([0.0, 1.0, 0.0], [[0.0, 1.0, 1.0], [1.0, 1.0, 1.0], [1.0, 1.0, 0.0], [0.0, 1.0, 0.0]]),
    ([0.0, -1.0, 0.0], [[0.0, 0.0, 0.0], [1.0, 0.0, 0.0], [1.0, 0.0, 1.0], [0.0, 0.0, 1.0]]),
];

fn grass_tint(x: usize, z: usize) -> [f32; 3] {
    let broad = value_noise(x as f32 / 26.0 + 11.0, z as f32 / 26.0 + 7.0);
    let fine = value_noise(x as f32 / 8.0 + 3.0, z as f32 / 8.0 + 19.0);
    let dry = (broad * 0.75 + fine * 0.25).clamp(0.0, 1.0);
    let r = 0.18 + 0.20 * dry;
    let g = 0.46 + 0.24 * (1.0 - dry * 0.5);
    let b = 0.10 + 0.08 * fine;
    [r, g, b]
}

fn build_chunk(blocks: &[u8], ox: usize, oz: usize) -> Vec<Vertex> {
    let mut verts = Vec::new();
    let uv_quad = [[0.0f32, 0.0f32], [1.0, 0.0], [1.0, 1.0], [0.0, 1.0]];

    for y in 0..HEIGHT {
        for z in 0..CHUNK {
            for x in 0..CHUNK {
                let wx = ox + x;
                let wz = oz + z;
                let b = blocks[idx(wx, y, wz)];
                if b == AIR {
                    continue;
                }
                for (f, (normal, corners)) in FACES.iter().enumerate() {
                    let nx = wx as i32 + normal[0] as i32;
                    let ny = y as i32 + normal[1] as i32;
                    let nz = wz as i32 + normal[2] as i32;
                    if block_at(blocks, nx, ny, nz) != AIR {
                        continue;
                    }
                    let row = face_row(b, f);
                    let tinted = blocks::find(b).map(|d| d.tinted).unwrap_or(false);
                    let tint = if tinted && f != 5 { grass_tint(wx, wz) } else { [1.0f32, 1.0, 1.0] };
                    let shade = match f {
                        4 => 1.0,
                        5 => 0.55,
                        _ => 0.82,
                    };
                    let color = [tint[0] * shade, tint[1] * shade, tint[2] * shade];
                    let side = normal[1] == 0.0;
                    for i in [0usize, 1, 2, 0, 2, 3] {
                        let c = corners[i];
                        let v = if side { 1.0 - uv_quad[i][1] } else { uv_quad[i][1] };
                        verts.push(Vertex {
                            pos: [wx as f32 + c[0], y as f32 + c[1], wz as f32 + c[2]],
                            normal: *normal,
                            uv: [uv_quad[i][0], (row + v) / TEX_ROWS as f32],
                            color,
                        });
                    }
                }
            }
        }
    }
    verts
}

fn skin_quad(
    out: &mut Vec<Vertex>,
    c: Vec3,
    ax: Vec3,
    ay: Vec3,
    az: Vec3,
    half: Vec3,
    uv: [f32; 4],
) {
    let corners = [
        c - ax * half.x - ay * half.y + az * half.z,
        c + ax * half.x - ay * half.y + az * half.z,
        c + ax * half.x + ay * half.y + az * half.z,
        c - ax * half.x + ay * half.y + az * half.z,
    ];
    let n = az;
    let uvs = [
        [uv[0], uv[3]],
        [uv[2], uv[3]],
        [uv[2], uv[1]],
        [uv[0], uv[1]],
    ];
    for i in [0usize, 1, 2, 0, 2, 3] {
        out.push(Vertex {
            pos: corners[i].to_array(),
            normal: n.to_array(),
            uv: uvs[i],
            color: [1.0, 1.0, 1.0],
        });
    }
}

fn player_box(out: &mut Vec<Vertex>, center: Vec3, size: Vec3, uv: [f32; 4]) {
    let ax = Vec3::X;
    let ay = Vec3::Y;
    let az = Vec3::Z;
    let half = size * 0.5;
    skin_quad(out, center + az * half.z, ax, ay, az, half, uv);
    skin_quad(out, center - az * half.z, ax, ay, -az, half, uv);
    skin_quad(out, center + ax * half.x, az, ay, ax, half, uv);
    skin_quad(out, center - ax * half.x, az, ay, -ax, half, uv);
    skin_quad(out, center + ay * half.y, ax, az, ay, half, uv);
    skin_quad(out, center - ay * half.y, ax, az, -ay, half, uv);
}

fn player_verts(base: Vec3, _yaw: f32) -> Vec<Vertex> {
    let mut out: Vec<Vertex> = Vec::new();
    player_box(
        &mut out,
        base + Vec3::Y * 0.45,
        Vec3::new(0.9, 0.9, 0.9),
        [8.0 / 64.0, 16.0 / 64.0, 16.0 / 64.0, 24.0 / 64.0],
    );
    out
}

fn right_axis(yaw: f32) -> Vec3 {
    Vec3::new(-yaw.cos(), 0.0, yaw.sin())
}

fn build_atlas() -> (u32, u32, Vec<u8>) {
    const CELL: u32 = 16;

    let names = [
        "grass", "grass_side", "dirt", "stone", "oak_wood", "oak_wood_up",
    ];
    let defaults: [[u8; 3]; 6] = [
        [90, 170, 70],
        [120, 95, 55],
        [130, 95, 60],
        [130, 130, 135],
        [120, 85, 50],
        [160, 130, 85],
    ];

    let mut data = vec![0u8; (CELL * CELL * TEX_ROWS as u32 * 4) as usize];
    let mut img_dir: Option<std::path::PathBuf> = None;
    for c in blocks::candidate_roots() {
        let p = c.join("images");
        if p.is_dir() {
            img_dir = Some(p);
            break;
        }
    }

    let mut cells: Vec<Vec<u8>> = vec![vec![0u8; (CELL * CELL * 4) as usize]; names.len()];
    for (row, name) in names.iter().enumerate() {
        let mut bytes_opt: Option<Vec<u8>> = None;
        if let Some(dir) = &img_dir {
            bytes_opt = std::fs::read(dir.join("blocks").join(format!("{}.png", name))).ok();
            if bytes_opt.is_none() {
                bytes_opt = std::fs::read(dir.join(format!("{}.png", name))).ok();
            }
        }
        let mut painted = false;
        if let Some(bytes) = bytes_opt {
            if let Ok(img) = image::load_from_memory(&bytes) {
                let rgba = img.to_rgba8();
                let (iw, ih) = rgba.dimensions();
                if iw > 0 && ih > 0 {
                    let raw = rgba.as_raw().clone();
                    for y in 0..CELL {
                        for x in 0..CELL {
                            let sx = (x * iw / CELL).min(iw - 1);
                            let sy = (y * ih / CELL).min(ih - 1);
                            let si = ((sy * iw + sx) * 4) as usize;
                            let di = ((y * CELL + x) * 4) as usize;
                            cells[row][di..di + 4].copy_from_slice(&raw[si..si + 4]);
                        }
                    }
                    painted = true;
                }
            }
        }
        if !painted {
            let col = defaults[row];
            for y in 0..CELL {
                for x in 0..CELL {
                    let di = ((y * CELL + x) * 4) as usize;
                    let chk = if (x / 2 + y / 2) % 2 == 0 { 1.0f32 } else { 0.9 };
                    cells[row][di] = (col[0] as f32 * chk) as u8;
                    cells[row][di + 1] = (col[1] as f32 * chk) as u8;
                    cells[row][di + 2] = (col[2] as f32 * chk) as u8;
                    cells[row][di + 3] = 255;
                }
            }
        }
    }

    let side_mask = if names.len() > 1 { Some(cells[1].clone()) } else { None };

    // прозрачные пиксели (маска) светились чёрным: заливаем подложкой
    for row in 0..names.len() {
        let total = (CELL * CELL) as usize;
        if !(0..total).any(|i| cells[row][i * 4 + 3] < 250) {
            continue;
        }
        let mut avg = [0u32; 3];
        let mut n = 0u32;
        for i in 0..total {
            if cells[row][i * 4 + 3] > 128 {
                avg[0] += cells[row][i * 4] as u32;
                avg[1] += cells[row][i * 4 + 1] as u32;
                avg[2] += cells[row][i * 4 + 2] as u32;
                n += 1;
            }
        }
        let flat = if n > 0 {
            [(avg[0] / n) as u8, (avg[1] / n) as u8, (avg[2] / n) as u8]
        } else {
            defaults[row]
        };
        let under = if names[row] == "grass_side" { 2 } else { row };
        for i in 0..total {
            let ui = i * 4;
            let a = cells[row][ui + 3] as u32;
            for c in 0..3 {
                let base = if under == row { flat[c] } else { cells[under][ui + c] };
                let src = cells[row][ui + c] as u32;
                cells[row][ui + c] = ((src * a + base as u32 * (255 - a)) / 255) as u8;
            }
            cells[row][ui + 3] = 255;
        }
    }

    for row in 0..names.len() {
        let off = row * (CELL * CELL * 4) as usize;
        data[off..off + cells[row].len()].copy_from_slice(&cells[row]);
    }

    for t in blocks::mod_textures() {
        let row = t.row as u32;
        if row as usize >= TEX_ROWS || row < 6 {
            continue;
        }
        let off = row as usize * (CELL * CELL * 4) as usize;
        let len = (CELL * CELL * 4) as usize;
        let mut painted = false;
        if let Some(p) = &t.path {
            if let Ok(bytes) = std::fs::read(p) {
                if let Ok(img) = image::load_from_memory(&bytes) {
                    let rgba = img.to_rgba8();
                    let (iw, ih) = rgba.dimensions();
                    if iw > 0 && ih > 0 {
                        let raw = rgba.as_raw().clone();
                        let cell = &mut data[off..off + len];
                        for y in 0..CELL {
                            for x in 0..CELL {
                                let sx = (x * iw / CELL).min(iw - 1);
                                let sy = (y * ih / CELL).min(ih - 1);
                                let si = ((sy * iw + sx) * 4) as usize;
                                let di = ((y * CELL + x) * 4) as usize;
                                let a = raw[si + 3] as u32;
                                if a < 128 {
                                    cell[di] = 34;
                                    cell[di + 1] = 66;
                                    cell[di + 2] = 26;
                                    cell[di + 3] = 255;
                                } else {
                                    cell[di] = raw[si];
                                    cell[di + 1] = raw[si + 1];
                                    cell[di + 2] = raw[si + 2];
                                    cell[di + 3] = 255;
                                }
                            }
                        }
                        painted = true;
                    }
                }
            }
        }
        if !painted {
            let cell = &mut data[off..off + len];
            for i in 0..(CELL * CELL) as usize {
                let di = i * 4;
                cell[di] = t.color[0];
                cell[di + 1] = t.color[1];
                cell[di + 2] = t.color[2];
                cell[di + 3] = 255;
            }
        }
    }

    // небо: звёзды, луна, солнце из images\*.png, иначе рисуем сами
    let sky_rows: [(u32, &str); 3] = [(13, "stars"), (14, "moon"), (15, "sun")];
    for (row, name) in sky_rows {
        let mut painted = false;
        if let Some(dir) = &img_dir {
            let mut bytes_opt = std::fs::read(dir.join("blocks").join(format!("{}.png", name))).ok();
            if bytes_opt.is_none() {
                bytes_opt = std::fs::read(dir.join(format!("{}.png", name))).ok();
            }
            if let Some(bytes) = bytes_opt {
                if let Ok(img) = image::load_from_memory(&bytes) {
                    let rgba = img.to_rgba8();
                    let (iw, ih) = rgba.dimensions();
                    if iw > 0 && ih > 0 {
                        let raw = rgba.as_raw().clone();
                        for y in 0..CELL {
                            for x in 0..CELL {
                                let sx = (x * iw / CELL).min(iw - 1);
                                let sy = (y * ih / CELL).min(ih - 1);
                                let si = ((sy * iw + sx) * 4) as usize;
                                let di = (((row * CELL + y) * CELL + x) * 4) as usize;
                                data[di..di + 4].copy_from_slice(&raw[si..si + 4]);
                            }
                        }
                        painted = true;
                    }
                }
            }
        }
        if painted {
            continue;
        }
        for y in 0..CELL {
            for x in 0..CELL {
                let di = (((row * CELL + y) * CELL + x) * 4) as usize;
                let dx = x as f32 - 7.5;
                let dy = y as f32 - 7.5;
                let d = (dx * dx + dy * dy).sqrt();
                if name == "stars" {
                    let h = hash2((row as i32) * 31 + x as i32, y as i32 * 17);
                    let dot = h > 0.93 && d < 9.0;
                    data[di] = 255;
                    data[di + 1] = 255;
                    data[di + 2] = 245;
                    data[di + 3] = if dot { 255 } else { 0 };
                } else {
                    let core = if d < 5.0 { 1.0 } else { (1.0 - (d - 5.0) / 2.6).max(0.0) };
                    let base = if name == "moon" { [200.0f32, 210.0, 235.0] } else { [255.0, 250.0, 215.0] };
                    data[di] = base[0] as u8;
                    data[di + 1] = base[1] as u8;
                    data[di + 2] = base[2] as u8;
                    data[di + 3] = (255.0 * core) as u8;
                }
            }
        }
    }

    (CELL, CELL * TEX_ROWS as u32, data)
}

struct State {
    window: Arc<Window>,
    surface: wgpu::Surface<'static>,
    device: wgpu::Device,
    queue: wgpu::Queue,
    config: wgpu::SurfaceConfiguration,
    pipeline: wgpu::RenderPipeline,
    depth_view: wgpu::TextureView,
    uniform_buffer: wgpu::Buffer,
    sun_buffer: wgpu::Buffer,
    player_buffer: wgpu::Buffer,
    player_pipeline: wgpu::RenderPipeline,
    player_bind: wgpu::BindGroup,
    sky_pipeline: wgpu::RenderPipeline,
    time_of_day: f32,
    day_len: f32,
    do_cycle: bool,
    chat_open: bool,
    chat_input: String,
    chat_log: Vec<String>,
    snd: Snd,
    step_timer: f32,
    flying: bool,
    last_space: Option<std::time::Instant>,
    bind_group: wgpu::BindGroup,
    chunks: Vec<ChunkMesh>,
    blocks: Vec<u8>,
    seed: i32,
    camera: Camera,
    keys: [bool; 6],
    fullscreen: bool,
    hud_enabled: bool,
    mods_open: bool,
    menu_open: bool,
    main_menu: bool,
    worlds: Vec<String>,
    world_name: String,
    shader_mode: u8,
    shader_layout: wgpu::PipelineLayout,
    surf_format: wgpu::TextureFormat,
    packs: Vec<(String, String, std::path::PathBuf)>,
    pack_sel: usize,
    lib: u8,
    mod_sel: usize,
    lang: std::collections::HashMap<String, String>,
    gfx: u8,
    lang_ru: bool,
    selected: usize,
    inv_open: bool,
    inv_page: usize,
    inv: Vec<u8>,
    picked: Option<usize>,
    ui_buffer: wgpu::Buffer,
    ui_pipeline: wgpu::RenderPipeline,
    ui_bind_white: wgpu::BindGroup,
    ui_bind_atlas: wgpu::BindGroup,
    ui_bind_skin: wgpu::BindGroup,
    has_skin: bool,
    skin_px: Option<(u32, u32, Vec<u8>)>,
    cam_mode: u8,
    mouse: (f32, f32),
    hud: Hud,
    hud_timer: f32,
    tip: Tip,
    fps: f32,
    font: fontdue::Font,
}

impl State {
    async fn new(window: Arc<Window>) -> State {
        let size = window.inner_size();

        let instance = wgpu::Instance::new(wgpu::InstanceDescriptor {
            backends: wgpu::Backends::PRIMARY,
            ..Default::default()
        });
        let surface = instance.create_surface(window.clone()).unwrap();
        let adapter = instance
            .request_adapter(&wgpu::RequestAdapterOptions {
                power_preference: wgpu::PowerPreference::HighPerformance,
                compatible_surface: Some(&surface),
                force_fallback_adapter: false,
            })
            .await
            .unwrap();
        let (device, queue) = adapter
            .request_device(
                &wgpu::DeviceDescriptor {
                    label: Some("cubistic"),
                    required_features: wgpu::Features::empty(),
                    required_limits: wgpu::Limits::default(),
                },
                None,
            )
            .await
            .unwrap();

        let caps = surface.get_capabilities(&adapter);
        let format = caps.formats[0];
        let config = wgpu::SurfaceConfiguration {
            usage: wgpu::TextureUsages::RENDER_ATTACHMENT,
            format,
            width: size.width.max(1),
            height: size.height.max(1),
            present_mode: wgpu::PresentMode::Fifo,
            alpha_mode: caps.alpha_modes[0],
            view_formats: vec![],
            desired_maximum_frame_latency: 2,
        };
        surface.configure(&device, &config);
        let depth_view = create_depth(&device, &config);

        let (aw, ah, adata) = build_atlas();
        let texture = device.create_texture(&wgpu::TextureDescriptor {
            label: Some("atlas"),
            size: wgpu::Extent3d { width: aw, height: ah, depth_or_array_layers: 1 },
            mip_level_count: 1,
            sample_count: 1,
            dimension: wgpu::TextureDimension::D2,
            format: wgpu::TextureFormat::Rgba8UnormSrgb,
            usage: wgpu::TextureUsages::TEXTURE_BINDING | wgpu::TextureUsages::COPY_DST,
            view_formats: &[],
        });
        queue.write_texture(
            wgpu::ImageCopyTexture {
                texture: &texture,
                mip_level: 0,
                origin: wgpu::Origin3d::ZERO,
                aspect: wgpu::TextureAspect::All,
            },
            &adata,
            wgpu::ImageDataLayout {
                offset: 0,
                bytes_per_row: Some(4 * aw),
                rows_per_image: Some(ah),
            },
            wgpu::Extent3d { width: aw, height: ah, depth_or_array_layers: 1 },
        );
        let texture_view = texture.create_view(&wgpu::TextureViewDescriptor::default());
        let sampler = device.create_sampler(&wgpu::SamplerDescriptor {
            label: Some("atlas sampler"),
            address_mode_u: wgpu::AddressMode::ClampToEdge,
            address_mode_v: wgpu::AddressMode::ClampToEdge,
            mag_filter: wgpu::FilterMode::Nearest,
            min_filter: wgpu::FilterMode::Nearest,
            ..Default::default()
        });

        let uniform_buffer = device.create_buffer(&wgpu::BufferDescriptor {
            label: Some("uniforms"),
            size: std::mem::size_of::<Uniforms>() as u64,
            usage: wgpu::BufferUsages::UNIFORM | wgpu::BufferUsages::COPY_DST,
            mapped_at_creation: false,
        });

        let bgl = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
            label: Some("bind layout"),
            entries: &[
                wgpu::BindGroupLayoutEntry {
                    binding: 0,
                    visibility: wgpu::ShaderStages::VERTEX_FRAGMENT,
                    ty: wgpu::BindingType::Buffer {
                        ty: wgpu::BufferBindingType::Uniform,
                        has_dynamic_offset: false,
                        min_binding_size: None,
                    },
                    count: None,
                },
                wgpu::BindGroupLayoutEntry {
                    binding: 1,
                    visibility: wgpu::ShaderStages::FRAGMENT,
                    ty: wgpu::BindingType::Texture {
                        sample_type: wgpu::TextureSampleType::Float { filterable: true },
                        view_dimension: wgpu::TextureViewDimension::D2,
                        multisampled: false,
                    },
                    count: None,
                },
                wgpu::BindGroupLayoutEntry {
                    binding: 2,
                    visibility: wgpu::ShaderStages::FRAGMENT,
                    ty: wgpu::BindingType::Sampler(wgpu::SamplerBindingType::Filtering),
                    count: None,
                },
            ],
        });

        let bind_group = device.create_bind_group(&wgpu::BindGroupDescriptor {
            label: Some("bind group"),
            layout: &bgl,
            entries: &[
                wgpu::BindGroupEntry { binding: 0, resource: uniform_buffer.as_entire_binding() },
                wgpu::BindGroupEntry { binding: 1, resource: wgpu::BindingResource::TextureView(&texture_view) },
                wgpu::BindGroupEntry { binding: 2, resource: wgpu::BindingResource::Sampler(&sampler) },
            ],
        });

        let shader = device.create_shader_module(wgpu::ShaderModuleDescriptor {
            label: Some("world shader"),
            source: wgpu::ShaderSource::Wgsl(shader_src("world", SHADER).into()),
        });

        let layout = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
            label: Some("world layout"),
            bind_group_layouts: &[&bgl],
            push_constant_ranges: &[],
        });

        let packs = scan_packs();
        let mut pack_sel = 0usize;
        let mut shader = shader;
        if let Some((_, _, path)) = packs.first().filter(|_| false) {
            if let Ok(t) = std::fs::read_to_string(path) {
                if t.trim().is_empty() {
                    // папка шейдера без shader.wgsl — оставляем встроенный
                }
                shader = device.create_shader_module(wgpu::ShaderModuleDescriptor {
                    label: Some("pack shader"),
                    source: wgpu::ShaderSource::Wgsl(t.into()),
                });
                pack_sel = 0;
            }
        }
        let pipeline = create_world_pipeline(&device, &layout, format, &shader);

        let sky_shader = device.create_shader_module(wgpu::ShaderModuleDescriptor {
            label: Some("sky shader"),
            source: wgpu::ShaderSource::Wgsl(shader_src("sky", SKY_SHADER).into()),
        });
        let sky_pipeline = device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
            label: Some("sky pipeline"),
            layout: Some(&layout),
            vertex: wgpu::VertexState {
                module: &sky_shader,
                entry_point: "vs_main",
                buffers: &[wgpu::VertexBufferLayout {
                    array_stride: std::mem::size_of::<Vertex>() as u64,
                    step_mode: wgpu::VertexStepMode::Vertex,
                    attributes: &wgpu::vertex_attr_array![0 => Float32x3, 1 => Float32x3, 2 => Float32x2, 3 => Float32x3],
                }],
                compilation_options: Default::default(),
            },
            fragment: Some(wgpu::FragmentState {
                module: &sky_shader,
                entry_point: "fs_main",
                targets: &[Some(wgpu::ColorTargetState {
                    format,
                    blend: Some(wgpu::BlendState::ALPHA_BLENDING),
                    write_mask: wgpu::ColorWrites::ALL,
                })],
                compilation_options: Default::default(),
            }),
            primitive: wgpu::PrimitiveState {
                cull_mode: None,
                ..Default::default()
            },
            depth_stencil: Some(wgpu::DepthStencilState {
                format: DEPTH_FORMAT,
                depth_write_enabled: false,
                depth_compare: wgpu::CompareFunction::Less,
                stencil: wgpu::StencilState::default(),
                bias: wgpu::DepthBiasState::default(),
            }),
            multisample: wgpu::MultisampleState::default(),
            multiview: None,
        });

        let font = fontdue::Font::from_bytes(
            include_bytes!("C:/Windows/Fonts/consola.ttf") as &[u8],
            fontdue::FontSettings::default(),
        )
        .unwrap();

        let hud_w = 560u32;
        let hud_h = 240u32;
        let hud_start = vec![String::from("CUBISTIC")];
        let hud_data = rasterize_text(&hud_start, &font, hud_w as usize, hud_h as usize);
        let hud_texture = make_hud_texture(&device, &queue, &hud_data, hud_w, hud_h);
        let hud_view = hud_texture.create_view(&wgpu::TextureViewDescriptor::default());

        let hud_bgl = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
            label: Some("hud bgl"),
            entries: &[
                wgpu::BindGroupLayoutEntry {
                    binding: 0,
                    visibility: wgpu::ShaderStages::FRAGMENT,
                    ty: wgpu::BindingType::Texture {
                        sample_type: wgpu::TextureSampleType::Float { filterable: true },
                        view_dimension: wgpu::TextureViewDimension::D2,
                        multisampled: false,
                    },
                    count: None,
                },
                wgpu::BindGroupLayoutEntry {
                    binding: 1,
                    visibility: wgpu::ShaderStages::FRAGMENT,
                    ty: wgpu::BindingType::Sampler(wgpu::SamplerBindingType::Filtering),
                    count: None,
                },
            ],
        });
        let hud_sampler = device.create_sampler(&wgpu::SamplerDescriptor {
            mag_filter: wgpu::FilterMode::Linear,
            min_filter: wgpu::FilterMode::Linear,
            ..Default::default()
        });
        let hud_bind = device.create_bind_group(&wgpu::BindGroupDescriptor {
            label: Some("hud bind"),
            layout: &hud_bgl,
            entries: &[
                wgpu::BindGroupEntry { binding: 0, resource: wgpu::BindingResource::TextureView(&hud_view) },
                wgpu::BindGroupEntry { binding: 1, resource: wgpu::BindingResource::Sampler(&hud_sampler) },
            ],
        });
        let hud_pipeline = create_hud_pipeline(&device, &hud_bgl, format);
        let hud_buffer = device.create_buffer(&wgpu::BufferDescriptor {
            label: Some("hud verts"),
            size: (std::mem::size_of::<HudVertex>() * 6) as u64,
            usage: wgpu::BufferUsages::VERTEX | wgpu::BufferUsages::COPY_DST,
            mapped_at_creation: false,
        });
        let hud = Hud { bind: hud_bind, pipeline: hud_pipeline, buffer: hud_buffer, texture: hud_texture, w: hud_w, h: hud_h };
        let tip_w = 300u32;
        let tip_h = 34u32;
        let tip_data = rasterize_text(&[String::new()], &font, tip_w as usize, tip_h as usize);
        let tip_texture = make_hud_texture(&device, &queue, &tip_data, tip_w, tip_h);
        let tip_view = tip_texture.create_view(&wgpu::TextureViewDescriptor::default());
        let tip_bind = device.create_bind_group(&wgpu::BindGroupDescriptor {
            label: Some("tip bind"),
            layout: &hud_bgl,
            entries: &[
                wgpu::BindGroupEntry { binding: 0, resource: wgpu::BindingResource::TextureView(&tip_view) },
                wgpu::BindGroupEntry { binding: 1, resource: wgpu::BindingResource::Sampler(&hud_sampler) },
            ],
        });
        let sun_buffer = device.create_buffer(&wgpu::BufferDescriptor {
            label: Some("sun verts"),
            size: (std::mem::size_of::<Vertex>() * 512) as u64,
            usage: wgpu::BufferUsages::VERTEX | wgpu::BufferUsages::COPY_DST,
            mapped_at_creation: false,
        });
        let tip_buffer = device.create_buffer(&wgpu::BufferDescriptor {
            label: Some("tip verts"),
            size: (std::mem::size_of::<HudVertex>() * 6) as u64,
            usage: wgpu::BufferUsages::VERTEX | wgpu::BufferUsages::COPY_DST,
            mapped_at_creation: false,
        });

        let white_tex = device.create_texture(&wgpu::TextureDescriptor {
            label: Some("white"),
            size: wgpu::Extent3d { width: 1, height: 1, depth_or_array_layers: 1 },
            mip_level_count: 1,
            sample_count: 1,
            dimension: wgpu::TextureDimension::D2,
            format: wgpu::TextureFormat::Rgba8UnormSrgb,
            usage: wgpu::TextureUsages::TEXTURE_BINDING | wgpu::TextureUsages::COPY_DST,
            view_formats: &[],
        });
        queue.write_texture(
            wgpu::ImageCopyTexture {
                texture: &white_tex,
                mip_level: 0,
                origin: wgpu::Origin3d::ZERO,
                aspect: wgpu::TextureAspect::All,
            },
            &[255u8, 255, 255, 255],
            wgpu::ImageDataLayout { offset: 0, bytes_per_row: Some(4), rows_per_image: Some(1) },
            wgpu::Extent3d { width: 1, height: 1, depth_or_array_layers: 1 },
        );

        let white_view = white_tex.create_view(&wgpu::TextureViewDescriptor::default());

        let mut has_skin = false;
        let mut skin_px_data: Option<(u32, u32, Vec<u8>)> = None;
        let mut skin_tex: Option<wgpu::Texture> = None;
        for path in ["game/images/player_skin.png", "images/player_skin.png", "game/images/skin.png"] {
            if let Ok(bytes) = std::fs::read(path) {
                if let Ok(img) = image::load_from_memory(&bytes) {
                    let rgba = img.to_rgba8();
                    let (sw, sh) = rgba.dimensions();
                    let tex = device.create_texture(&wgpu::TextureDescriptor {
                        label: Some("skin"),
                        size: wgpu::Extent3d { width: sw, height: sh, depth_or_array_layers: 1 },
                        mip_level_count: 1,
                        sample_count: 1,
                        dimension: wgpu::TextureDimension::D2,
                        format: wgpu::TextureFormat::Rgba8UnormSrgb,
                        usage: wgpu::TextureUsages::TEXTURE_BINDING | wgpu::TextureUsages::COPY_DST,
                        view_formats: &[],
                    });
                    queue.write_texture(
                        wgpu::ImageCopyTexture {
                            texture: &tex,
                            mip_level: 0,
                            origin: wgpu::Origin3d::ZERO,
                            aspect: wgpu::TextureAspect::All,
                        },
                        rgba.as_raw(),
                        wgpu::ImageDataLayout {
                            offset: 0,
                            bytes_per_row: Some(4 * sw),
                            rows_per_image: Some(sh),
                        },
                        wgpu::Extent3d { width: sw, height: sh, depth_or_array_layers: 1 },
                    );
                    has_skin = true;
                    skin_tex = Some(tex);
                    skin_px_data = Some((sw, sh, rgba.as_raw().clone()));
                    break;
                }
            }
        }
        let skin_view = match &skin_tex {
            Some(t) => t.create_view(&wgpu::TextureViewDescriptor::default()),
            None => white_tex.create_view(&wgpu::TextureViewDescriptor::default()),
        };

        let ui_bgl = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
            label: Some("ui bgl"),
            entries: &[
                wgpu::BindGroupLayoutEntry {
                    binding: 0,
                    visibility: wgpu::ShaderStages::FRAGMENT,
                    ty: wgpu::BindingType::Texture {
                        sample_type: wgpu::TextureSampleType::Float { filterable: true },
                        view_dimension: wgpu::TextureViewDimension::D2,
                        multisampled: false,
                    },
                    count: None,
                },
                wgpu::BindGroupLayoutEntry {
                    binding: 1,
                    visibility: wgpu::ShaderStages::FRAGMENT,
                    ty: wgpu::BindingType::Sampler(wgpu::SamplerBindingType::Filtering),
                    count: None,
                },
            ],
        });
        let ui_sampler = device.create_sampler(&wgpu::SamplerDescriptor {
            mag_filter: wgpu::FilterMode::Nearest,
            min_filter: wgpu::FilterMode::Nearest,
            ..Default::default()
        });
        let ui_bind_white = device.create_bind_group(&wgpu::BindGroupDescriptor {
            label: Some("ui white"),
            layout: &ui_bgl,
            entries: &[
                wgpu::BindGroupEntry { binding: 0, resource: wgpu::BindingResource::TextureView(&white_view) },
                wgpu::BindGroupEntry { binding: 1, resource: wgpu::BindingResource::Sampler(&ui_sampler) },
            ],
        });
        let ui_bind_atlas = device.create_bind_group(&wgpu::BindGroupDescriptor {
            label: Some("ui atlas"),
            layout: &ui_bgl,
            entries: &[
                wgpu::BindGroupEntry { binding: 0, resource: wgpu::BindingResource::TextureView(&texture_view) },
                wgpu::BindGroupEntry { binding: 1, resource: wgpu::BindingResource::Sampler(&ui_sampler) },
            ],
        });
        let ui_bind_skin = device.create_bind_group(&wgpu::BindGroupDescriptor {
            label: Some("ui skin"),
            layout: &ui_bgl,
            entries: &[
                wgpu::BindGroupEntry { binding: 0, resource: wgpu::BindingResource::TextureView(&skin_view) },
                wgpu::BindGroupEntry { binding: 1, resource: wgpu::BindingResource::Sampler(&ui_sampler) },
            ],
        });
        let player_buffer = device.create_buffer(&wgpu::BufferDescriptor {
            label: Some("player verts"),
            size: (std::mem::size_of::<Vertex>() * 512) as u64,
            usage: wgpu::BufferUsages::VERTEX | wgpu::BufferUsages::COPY_DST,
            mapped_at_creation: false,
        });
        let player_shader = device.create_shader_module(wgpu::ShaderModuleDescriptor {
            label: Some("player shader"),
            source: wgpu::ShaderSource::Wgsl(shader_src("player", SHADER).into()),
        });
        let player_pipeline = create_world_pipeline(&device, &layout, format, &player_shader);
        let player_bind = device.create_bind_group(&wgpu::BindGroupDescriptor {
            label: Some("player bind"),
            layout: &bgl,
            entries: &[
                wgpu::BindGroupEntry { binding: 0, resource: uniform_buffer.as_entire_binding() },
                wgpu::BindGroupEntry { binding: 1, resource: wgpu::BindingResource::TextureView(&skin_view) },
                wgpu::BindGroupEntry { binding: 2, resource: wgpu::BindingResource::Sampler(&ui_sampler) },
            ],
        });
        let ui_pipeline = create_ui_pipeline(&device, &ui_bgl, format);
        let ui_buffer = device.create_buffer(&wgpu::BufferDescriptor {
            label: Some("ui verts"),
            size: (std::mem::size_of::<UiVertex>() * 4096) as u64,
            usage: wgpu::BufferUsages::VERTEX | wgpu::BufferUsages::COPY_DST,
            mapped_at_creation: false,
        });

        let seed = 1;
        let blocks = build_world(seed);
        let mut chunks = Vec::new();
        for cz in 0..CHUNKS {
            for cx in 0..CHUNKS {
                let ox = cx * CHUNK;
                let oz = cz * CHUNK;
                let verts = build_chunk(&blocks, ox, oz);
                let count = verts.len() as u32;
                let buffer = device.create_buffer(&wgpu::BufferDescriptor {
                    label: Some("chunk"),
                    size: (std::mem::size_of::<Vertex>() * verts.len()).max(4) as u64,
                    usage: wgpu::BufferUsages::VERTEX | wgpu::BufferUsages::COPY_DST,
                    mapped_at_creation: false,
                });
                if !verts.is_empty() {
                    queue.write_buffer(&buffer, 0, bytemuck::cast_slice(&verts));
                }
                chunks.push(ChunkMesh {
                    buffer,
                    count,
                    center: Vec3::new((ox + CHUNK / 2) as f32, 0.0, (oz + CHUNK / 2) as f32),
                });
            }
        }

        let start_h = terrain_height(WORLD / 2, WORLD / 2, seed) as f32;
        let camera = Camera {
            pos: Vec3::new(WORLD as f32 / 2.0, start_h + 4.0, WORLD as f32 / 2.0),
            yaw: 0.0,
            pitch: -0.25,
            vel: Vec3::ZERO,
        };

        State {
            window,
            surface,
            device,
            queue,
            config,
            pipeline,
            depth_view,
            uniform_buffer,
            sun_buffer,
            player_buffer,
            player_pipeline,
            player_bind,
            sky_pipeline,
            time_of_day: 0.28,
            day_len: 480.0,
            do_cycle: true,
            chat_open: false,
            chat_input: String::new(),
            chat_log: Vec::new(),
            snd: Snd::new(),
            step_timer: 0.0,
            flying: false,
            last_space: None,
            bind_group,
            chunks,
            blocks,
            seed,
            camera,
            keys: [false; 6],
            fullscreen: false,
            hud_enabled: false,
            mods_open: false,
            menu_open: false,
            main_menu: true,
            worlds: Vec::new(),
            world_name: String::new(),
            shader_mode: 1,
            shader_layout: layout,
            surf_format: format,
            packs,
            pack_sel,
            lib: 0,
            mod_sel: 0,
            lang: std::collections::HashMap::new(),
            gfx: 1,
            lang_ru: true,
            selected: 0,
            inv_open: false,
            inv_page: 0,
            inv: blocks::all().iter().map(|d| d.id).collect(),
            picked: None,
            ui_buffer,
            ui_pipeline,
            ui_bind_white,
            ui_bind_atlas,
            ui_bind_skin,
            has_skin,
            skin_px: skin_px_data,
            cam_mode: 0,
            mouse: (0.0, 0.0),
            hud,
            hud_timer: 0.0,
            tip: Tip { bind: tip_bind, buffer: tip_buffer, texture: tip_texture, w: tip_w, h: tip_h, name: String::new() },
            fps: 0.0,
            font,
        }
    }

    fn rebuild_chunk(&mut self, ci: usize) {
        let cx = ci % CHUNKS;
        let cz = ci / CHUNKS;
        let ox = cx * CHUNK;
        let oz = cz * CHUNK;
        let verts = build_chunk(&self.blocks, ox, oz);
        let buffer = self.device.create_buffer(&wgpu::BufferDescriptor {
            label: Some("chunk"),
            size: (std::mem::size_of::<Vertex>() * verts.len()).max(4) as u64,
            usage: wgpu::BufferUsages::VERTEX | wgpu::BufferUsages::COPY_DST,
            mapped_at_creation: false,
        });
        if !verts.is_empty() {
            self.queue.write_buffer(&buffer, 0, bytemuck::cast_slice(&verts));
        }
        self.chunks[ci].buffer = buffer;
        self.chunks[ci].count = verts.len() as u32;
    }

    fn rebuild_all(&mut self) {
        for ci in 0..self.chunks.len() {
            self.rebuild_chunk(ci);
        }
    }

    fn menu_open(&self) -> bool {
        self.inv_open || self.mods_open || self.menu_open || self.lib != 0 || self.main_menu
    }

    fn load_lang(&mut self) {
        self.lang.clear();
        let name = if self.lang_ru { "ru_ru.json" } else { "en_us.json" };
        for d in blocks::candidate_roots() {
            let p = d.join("lang").join(name);
            let t = match std::fs::read_to_string(&p) {
                Ok(t) => t,
                Err(_) => continue,
            };
            for line in t.lines() {
                let l = line.trim().trim_start_matches('\u{feff}');
                if l.is_empty() || l.starts_with('#') || l.starts_with('{') || l.starts_with('}') {
                    continue;
                }
                let mut kv = l.splitn(2, ':');
                let k = kv.next().unwrap_or("").trim().trim_matches('"').to_lowercase();
                let v = kv
                    .next()
                    .unwrap_or("")
                    .trim()
                    .trim_end_matches(',')
                    .trim()
                    .trim_matches('"')
                    .to_string();
                if !k.is_empty() && !v.is_empty() {
                    self.lang.insert(k, v);
                }
            }
            break;
        }
        for d in blocks::candidate_roots() {
            let mdir = d.join("mods");
            if !mdir.is_dir() {
                continue;
            }
            let rd = match std::fs::read_dir(&mdir) {
                Ok(r) => r,
                Err(_) => continue,
            };
            for e in rd.flatten() {
                let p = e.path().join("lang").join(name);
                let t = match std::fs::read_to_string(&p) {
                    Ok(t) => t,
                    Err(_) => continue,
                };
                for line in t.lines() {
                    let l = line.trim().trim_start_matches('\u{feff}');
                    if l.is_empty() || l.starts_with('#') || l.starts_with('{') || l.starts_with('}') {
                        continue;
                    }
                    let mut kv = l.splitn(2, ':');
                    let k = kv.next().unwrap_or("").trim().trim_matches('"').to_lowercase();
                    let v = kv
                        .next()
                        .unwrap_or("")
                        .trim()
                        .trim_end_matches(',')
                        .trim()
                        .trim_matches('"')
                        .to_string();
                    if !k.is_empty() && !v.is_empty() {
                        self.lang.insert(k, v);
                    }
                }
            }
        }
    }

    fn tr(&self, key: &str) -> String {
        let k = key.to_lowercase();
        if let Some(v) = self.lang.get(&k) {
            return v.clone();
        }
        let ru = self.lang_ru;
        match k.as_str() {
            "paused" => if ru { "ПАУЗА" } else { "PAUSED" },
            "resume" => if ru { "Продолжить" } else { "Resume" },
            "shaders" => if ru { "Шейдеры" } else { "Shaders" },
            "graphics" => if ru { "Графика" } else { "Graphics" },
            "language" => if ru { "Язык" } else { "Language" },
            "mods" => if ru { "Моды" } else { "Mods" },
            "quit game" => if ru { "Выход из игры" } else { "Quit game" },
            "flat" => if ru { "Плоский" } else { "Flat" },
            "warm" => if ru { "Тёплый" } else { "Warm" },
            "cinematic" => if ru { "Кинематограф" } else { "Cinematic" },
            "low" => if ru { "Низкая" } else { "Low" },
            "medium" => if ru { "Средняя" } else { "Medium" },
            "high" => if ru { "Высокая" } else { "High" },
            "play" => if ru { "Играть" } else { "Play" },
            "new world" => if ru { "Новый мир" } else { "New world" },
            "exit" => if ru { "Выход" } else { "Exit" },
            "menu hint" => if ru { "ЛКМ - выбрать   ESC - закрыть" } else { "LMB - choose   ESC - close" },
            _ => key,
        }
        .to_string()
    }

    fn tr_block(&self, key: &str, base: &str) -> String {
        self.lang.get(key).cloned().unwrap_or_else(|| base.to_string())
    }

    fn sun_dir(&self) -> Vec3 {
        let a = self.time_of_day * std::f32::consts::TAU;
        Vec3::new(-0.18, a.sin(), a.cos() * 0.92).normalize()
    }

    fn sky_color(&self) -> [f64; 3] {
        let el = self.sun_dir().y;
        let day = (el * 3.0).clamp(0.0, 1.0);
        let dusk = (1.0 - el.abs() * 4.0).clamp(0.0, 1.0);
        let mut c = [
            0.03 + (0.62 - 0.03) * day,
            0.04 + (0.78 - 0.04) * day,
            0.10 + (0.98 - 0.10) * day,
        ];
        c[0] += 0.25 * dusk;
        c[1] -= 0.02 * dusk;
        c[2] -= 0.08 * dusk;
        [c[0] as f64, c[1] as f64, c[2] as f64]
    }

    fn view_dist(&self) -> f32 {
        match self.gfx {
            0 => 60.0,
            1 => 90.0,
            _ => 140.0,
        }
    }

    fn menu_lines(&self) -> Vec<String> {
        if self.main_menu {
            let mut v = vec![String::from("CUBISTIC"), self.tr("new world")];
            for w in &self.worlds {
                v.push(format!("  {}", w));
            }
            v.push(self.tr("exit"));
            v.push(self.tr("menu hint"));
            return v;
        }
        let ru = self.lang_ru;
        let sh = self.tr(match self.shader_mode {
            0 => "flat",
            2 => "cinematic",
            _ => "warm",
        });
        let gfx = self.tr(match self.gfx {
            0 => "low",
            1 => "medium",
            _ => "high",
        });
        let lang = if ru { "Русский" } else { "English" };
        vec![
            self.tr("paused"),
            self.tr("resume"),
            self.tr("shaders"),
            format!("{}: {}", self.tr("graphics"), gfx),
            format!("{}: {}", self.tr("language"), lang),
            self.tr("mods"),
            self.tr("quit game"),
            self.tr("menu hint"),
        ]
    }

    fn menu_view(&self) -> (f32, f32, f32) {
        let s = 1.5f32;
        let ox = (self.config.width as f32 - self.hud.w as f32 * s) / 2.0;
        let oy = self.config.height as f32 * 0.12;
        (ox, oy, s)
    }

    fn panel_view(&self) -> (f32, f32, f32) {
        let s = 1.5f32;
        let ox = (self.config.width as f32 - self.hud.w as f32 * s) / 2.0;
        let oy = (self.config.height as f32 - self.hud.h as f32 * s) / 2.0;
        (ox, oy, s)
    }

    fn row_y(oy: f32, s: f32, line: usize) -> f32 {
        oy + (6.0 + line as f32 * 28.0) * s
    }

    fn menu_row(&self) -> usize {
        let (_, oy, s) = if self.main_menu { self.panel_view() } else { self.menu_view() };
        let y = (self.mouse.1 - oy - 4.0 * s) / (28.0 * s);
        if y < 0.0 || y > 7.0 {
            99
        } else {
            y as usize
        }
    }

    fn submit_chat(&mut self) {
        let line = self.chat_input.trim().to_string();
        self.chat_open = false;
        self.chat_input.clear();
        self.hud_timer = 0.0;
        if line.is_empty() {
            return;
        }
        self.chat_log.push(format!("> {}", line));
        let resp = self.run_command(&line);
        if !resp.is_empty() {
            self.chat_log.push(resp);
        }
        while self.chat_log.len() > 7 {
            self.chat_log.remove(0);
        }
    }

    fn run_command(&mut self, line: &str) -> String {
        let body = line.trim().trim_start_matches('/').trim();
        let mut it = body.split_whitespace();
        let cmd = it.next().unwrap_or("").to_lowercase();
        let ru = self.lang_ru;
        match cmd.as_str() {
            "time" => {
                let sub = it.next().unwrap_or("").to_lowercase();
                let arg = it.next().unwrap_or("");
                match sub.as_str() {
                    "set" => {
                        let t = match arg.to_lowercase().as_str() {
                            "day" | "noon" => Some(0.25f32),
                            "night" | "midnight" => Some(0.75),
                            "sunrise" | "morning" => Some(0.0),
                            "sunset" | "evening" => Some(0.5),
                            _ => arg.parse::<f32>().ok().map(|h| (h / 24.0).rem_euclid(1.0)),
                        };
                        match t {
                            Some(v) => {
                                self.time_of_day = v.rem_euclid(1.0);
                                if ru { "время установлено".to_string() } else { "time set".to_string() }
                            }
                            None => if ru {
                                "используй: time set day|night|noon|midnight|<0-24>".to_string()
                            } else {
                                "usage: time set day|night|noon|midnight|<0-24>".to_string()
                            },
                        }
                    }
                    "add" => match arg.parse::<f32>() {
                        Ok(secs) => {
                            self.time_of_day = (self.time_of_day + secs / self.day_len).rem_euclid(1.0);
                            if ru { "время сдвинуто".to_string() } else { "time added".to_string() }
                        }
                        Err(_) => if ru {
                            "используй: time add <секунды>".to_string()
                        } else {
                            "usage: time add <seconds>".to_string()
                        },
                    },
                    _ => if ru { "используй: time set|add".to_string() } else { "usage: time set|add".to_string() },
                }
            }
            "gamerule" => {
                let rule = it.next().unwrap_or("").to_lowercase();
                let val = it.next().unwrap_or("").to_lowercase();
                match rule.as_str() {
                    "dodaylightcycle" => {
                        if val.is_empty() {
                            let s = if self.do_cycle { "true" } else { "false" };
                            format!("doDaylightCycle = {}", s)
                        } else {
                            self.do_cycle = val != "false";
                            format!("doDaylightCycle = {}", if self.do_cycle { "true" } else { "false" })
                        }
                    }
                    _ => if ru { "правила: doDaylightCycle".to_string() } else { "rules: doDaylightCycle".to_string() },
                }
            }
            "help" | "" => if ru {
                "команды: /time set|add, /gamerule doDaylightCycle".to_string()
            } else {
                "commands: /time set|add, /gamerule doDaylightCycle".to_string()
            },
            other => format!("? {}", other),
        }
    }

    fn apply_pack(&mut self, idx: usize) {
        if idx >= self.packs.len() {
            return;
        }
        let path = self.packs[idx].2.clone();
        let text = match std::fs::read_to_string(&path) {
            Ok(t) => t,
            Err(_) => return,
        };
        if text.trim().is_empty() {
            return;
        }
        let shader = self.device.create_shader_module(wgpu::ShaderModuleDescriptor {
            label: Some("pack shader"),
            source: wgpu::ShaderSource::Wgsl(text.into()),
        });
        self.pipeline = create_world_pipeline(&self.device, &self.shader_layout, self.surf_format, &shader);
        self.pack_sel = idx;
        self.hud_timer = 0.0;
    }

    fn lib_lines(&self) -> Vec<String> {
        let mut v = vec![self.tr("shaders")];
        for (i, (n, _, _)) in self.packs.iter().enumerate() {
            v.push(if i == self.pack_sel {
                format!("> {}", n)
            } else {
                format!("  {}", n)
            });
        }
        v.push(String::new());
        if let Some((n, d, p)) = self.packs.get(self.pack_sel) {
            v.push(n.clone());
            if !d.is_empty() {
                v.push(d.clone());
            }
            if let Some(f) = p.file_name() {
                v.push(format!("shader.wgsl: {}", f.to_string_lossy()));
            }
        }
        v
    }

    fn lib_row(&self) -> usize {
        let (_, oy, s) = self.panel_view();
        let y = (self.mouse.1 - oy - 6.0 * s) / (28.0 * s);
        if y < 0.0 || y > 30.0 {
            99
        } else {
            y as usize
        }
    }

    fn lib_click(&mut self) {
        let row = self.lib_row();
        if row >= 1 && row - 1 < self.packs.len() {
            self.apply_pack(row - 1);
        }
    }

    fn saves_dir(&self) -> std::path::PathBuf {
        let base = std::env::current_exe()
            .ok()
            .and_then(|p| p.parent().map(|p| p.to_path_buf()))
            .unwrap_or_else(|| std::path::PathBuf::from("."));
        let worlds = base.join("worlds");
        if worlds.is_dir() {
            return worlds;
        }
        let old = base.join("saves");
        if old.is_dir() {
            return old;
        }
        worlds
    }

    fn refresh_worlds(&mut self) {
        self.worlds.clear();
        if let Ok(rd) = std::fs::read_dir(self.saves_dir()) {
            let mut v: Vec<_> = rd.flatten().filter(|e| e.path().is_dir()).collect();
            v.sort_by_key(|e| e.file_name());
            for e in v {
                if e.path().join("world.bin").is_file() {
                    if let Some(n) = e.file_name().to_str() {
                        self.worlds.push(n.to_string());
                    }
                }
            }
        }
    }

    fn save_world(&self) {
        if self.world_name.is_empty() {
            return;
        }
        let dir = self.saves_dir().join(&self.world_name);
        let _ = std::fs::create_dir_all(&dir);
        let _ = std::fs::write(dir.join("world.bin"), &self.blocks);
        let meta = format!(
            "name={}\nseed={}\ntime={}\nx={}\ny={}\nz={}\n",
            self.world_name, self.seed, self.time_of_day,
            self.camera.pos.x, self.camera.pos.y, self.camera.pos.z
        );
        let _ = std::fs::write(dir.join("meta.json"), meta);
    }

    fn load_world(&mut self, name: &str) -> bool {
        let dir = self.saves_dir().join(name);
        let data = match std::fs::read(dir.join("world.bin")) {
            Ok(d) => d,
            Err(_) => return false,
        };
        if data.len() != self.blocks.len() {
            return false;
        }
        self.blocks = data;
        self.rebuild_all();
        if let Ok(t) = std::fs::read_to_string(dir.join("meta.json")) {
            for line in t.lines() {
                let mut kv = line.splitn(2, '=');
                let k = kv.next().unwrap_or("");
                let v = kv.next().unwrap_or("").trim();
                match k {
                    "seed" => { if let Ok(s) = v.parse() { self.seed = s; } }
                    "time" => { if let Ok(s) = v.parse() { self.time_of_day = s; } }
                    "x" => { if let Ok(s) = v.parse() { self.camera.pos.x = s; } }
                    "y" => { if let Ok(s) = v.parse() { self.camera.pos.y = s; } }
                    "z" => { if let Ok(s) = v.parse() { self.camera.pos.z = s; } }
                    _ => {}
                }
            }
        }
        self.world_name = name.to_string();
        self.camera.vel = Vec3::ZERO;
        self.main_menu = false;
        self.set_menu_cursor();
        self.hud_timer = 0.0;
        true
    }

    fn new_world(&mut self) {
        let seed = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .map(|d| d.as_secs() as i32)
            .unwrap_or(1);
        self.seed = seed;
        self.blocks = build_world(seed);
        self.rebuild_all();
        let h = terrain_height(WORLD / 2, WORLD / 2, seed) as f32;
        self.camera.pos = Vec3::new(WORLD as f32 / 2.0, h + 2.0, WORLD as f32 / 2.0);
        self.camera.vel = Vec3::ZERO;
        self.camera.yaw = 0.0;
        self.camera.pitch = -0.2;
        self.time_of_day = 0.3;
        self.world_name = format!("world{}", self.worlds.len() + 1);
        self.save_world();
        self.refresh_worlds();
        self.main_menu = false;
        self.set_menu_cursor();
        self.hud_timer = 0.0;
    }

    fn menu_click(&mut self, row: usize) {
        if self.main_menu {
            let n = self.worlds.len();
            if row == 1 {
                self.new_world();
            } else if row >= 2 && row < 2 + n {
                let name = self.worlds[row - 2].clone();
                self.load_world(&name);
            } else if row == 2 + n {
                self.save_world();
                std::process::exit(0);
            }
            return;
        }
        match row {
            1 => {
                self.menu_open = false;
                self.set_menu_cursor();
            }
            2 => {}
            3 => self.gfx = (self.gfx + 1) % 3,
            4 => {
                self.lang_ru = !self.lang_ru;
                self.load_lang();
            }
            5 => {
                self.menu_open = false;
                self.mods_open = true;
                self.set_menu_cursor();
            }
            6 => std::process::exit(0),
            _ => {}
        }
        self.hud_timer = 0.0;
    }

    fn set_menu_cursor(&self) {
        if self.menu_open() {
            let _ = self.window.set_cursor_grab(CursorGrabMode::None);
            self.window.set_cursor_visible(true);
        } else {
            grab_cursor(&self.window);
            self.window.set_cursor_visible(false);
        }
    }

    fn solid(&self, x: i32, y: i32, z: i32) -> bool {
        if x < 0 || z < 0 || y < 0 || x >= WORLD as i32 || z >= WORLD as i32 || y >= HEIGHT as i32 {
            return false;
        }
        self.blocks[idx(x as usize, y as usize, z as usize)] != AIR
    }

    fn hits(&self, p: Vec3) -> bool {
        let r = 0.3f32;
        let h = 1.75f32;
        let x0 = (p.x - r).floor() as i32;
        let x1 = (p.x + r).floor() as i32;
        let y0 = (p.y - h).floor() as i32;
        let y1 = (p.y - 0.05).floor() as i32;
        let z0 = (p.z - r).floor() as i32;
        let z1 = (p.z + r).floor() as i32;
        for bx in x0..=x1 {
            for by in y0..=y1 {
                for bz in z0..=z1 {
                    if self.solid(bx, by, bz) {
                        return true;
                    }
                }
            }
        }
        false
    }

    fn inv_box(&self) -> (f32, f32, f32, f32) {
        let w = 1000.0f32;
        let h = 560.0f32;
        let px = (self.config.width as f32 - w) / 2.0;
        let py = (self.config.height as f32 - h) / 2.0;
        (px, py, w, h)
    }

    fn inv_slot_pos(&self, slot: usize) -> (f32, f32) {
        let (px, py, _, _) = self.inv_box();
        (
            px + 160.0 + (slot % 10) as f32 * 68.0,
            py + 84.0 + (slot / 10) as f32 * 68.0,
        )
    }

    fn cell_hits_player(&self, bx: i32, by: i32, bz: i32) -> bool {
        let r = 0.3f32;
        let p = self.camera.pos;
        let (px0, px1) = (p.x - r, p.x + r);
        let (py0, py1) = (p.y - 1.75, p.y);
        let (pz0, pz1) = (p.z - r, p.z + r);
        let (bx0, bx1) = (bx as f32, bx as f32 + 1.0);
        let (by0, by1) = (by as f32, by as f32 + 1.0);
        let (bz0, bz1) = (bz as f32, bz as f32 + 1.0);
        px0 < bx1 && px1 > bx0 && py0 < by1 && py1 > by0 && pz0 < bz1 && pz1 > bz0
    }

    fn hover_name(&self) -> String {
        if !self.menu_open() {
            return String::new();
        }
        let screen = (self.config.width as f32, self.config.height as f32);
        let (mx, my) = self.mouse;
        let slot = 56.0;
        let gap = 8.0;
        let total = slot * 10.0 + gap * 9.0;
        let x0 = (screen.0 - total) / 2.0;
        let y0 = screen.1 - slot - 18.0;
        for i in 0..10usize {
            let x = x0 + (slot + gap) * i as f32;
            if mx >= x && mx <= x + slot && my >= y0 && my <= y0 + slot {
                if let Some(d) = self.inv.get(i).and_then(|id| blocks::find(*id)) {
                    return self.tr_block(&d.key, &d.name);
                }
            }
        }
        if self.inv_open {
            for slot in 0..50usize {
                let gi = self.inv_page * 50 + slot;
                let (cx, cy) = self.inv_slot_pos(slot);
                if mx >= cx && mx <= cx + 62.0 && my >= cy && my <= cy + 62.0 {
                    if let Some(d) = self.inv.get(gi).and_then(|id| blocks::find(*id)) {
                        return self.tr_block(&d.key, &d.name);
                    }
                }
            }
        }
        String::new()
    }

    fn inv_slot_at(&self) -> Option<usize> {
        let (mx, my) = self.mouse;
        for slot in 0..50usize {
            let gi = self.inv_page * 50 + slot;
            let (cx, cy) = self.inv_slot_pos(slot);
            if mx >= cx && mx <= cx + 62.0 && my >= cy && my <= cy + 62.0 {
                if gi < self.inv.len() {
                    return Some(gi);
                }
            }
        }
        None
    }

    fn pick_in_inventory(&mut self) {
        if let Some(gi) = self.inv_slot_at() {
            self.picked = Some(gi);
            self.selected = gi;
        } else {
            self.picked = None;
        }
    }

    fn inv_release(&mut self) {
        let src_idx = match self.picked {
            Some(p) => p,
            None => return,
        };
        if let Some(dst) = self.inv_slot_at() {
            if dst != src_idx {
                self.inv.swap(src_idx, dst);
                self.selected = dst;
                self.hud_timer = 0.0;
            }
        }
        self.picked = None;
    }

    fn place_block(&mut self) {
        let dir = Vec3::new(
            self.camera.yaw.sin() * self.camera.pitch.cos(),
            self.camera.pitch.sin(),
            self.camera.yaw.cos() * self.camera.pitch.cos(),
        );
        let mut p = self.camera.pos;
        let step = 0.08;
        let mut prev = p;
        for _ in 0..140 {
            p += dir * step;
            let bx = p.x.floor() as i32;
            let by = p.y.floor() as i32;
            let bz = p.z.floor() as i32;
            if bx < 0 || by < 0 || bz < 0 || bx >= WORLD as i32 || bz >= WORLD as i32 || by >= HEIGHT as i32 {
                return;
            }
            let cur = self.blocks[idx(bx as usize, by as usize, bz as usize)];
            if cur != AIR {
                let hx = prev.x.floor() as i32;
                let hy = prev.y.floor() as i32;
                let hz = prev.z.floor() as i32;
                if hx < 0 || hy < 0 || hz < 0 || hx >= WORLD as i32 || hz >= WORLD as i32 || hy >= HEIGHT as i32 {
                    return;
                }
                if self.blocks[idx(hx as usize, hy as usize, hz as usize)] != AIR {
                    return;
                }
                if self.cell_hits_player(hx, hy, hz) {
                    return;
                }
                let kind = match self.inv.get(self.selected) {
                    Some(id) => *id,
                    None => return,
                };
                self.blocks[idx(hx as usize, hy as usize, hz as usize)] = kind;
                let ci = (hz as usize / CHUNK) * CHUNKS + (hx as usize / CHUNK);
                self.rebuild_chunk(ci);
                return;
            }
            prev = p;
        }
    }

    fn skin_region(&self, x0: u32, y0: u32, x1: u32, y1: u32) -> [f32; 4] {
        let (w, h, px) = match &self.skin_px {
            Some(t) => t,
            None => return [0.85, 0.68, 0.5, 1.0],
        };
        if *w == 0 || *h == 0 {
            return [0.85, 0.68, 0.5, 1.0];
        }
        let sx0 = x0.min(*w - 1);
        let sx1 = x1.min(*w);
        let sy0 = y0.min(*h - 1);
        let sy1 = y1.min(*h);
        let mut r = 0.0f32;
        let mut g = 0.0f32;
        let mut b = 0.0f32;
        let mut n = 0.0f32;
        for y in sy0..sy1 {
            for x in sx0..sx1 {
                let i = ((y * *w + x) * 4) as usize;
                if i + 3 < px.len() {
                    r += px[i] as f32 / 255.0;
                    g += px[i + 1] as f32 / 255.0;
                    b += px[i + 2] as f32 / 255.0;
                    n += 1.0;
                }
            }
        }
        if n == 0.0 {
            [0.85, 0.68, 0.5, 1.0]
        } else {
            [r / n, g / n, b / n, 1.0]
        }
    }

    fn build_ui(&mut self) -> (u32, u32, u32) {
        let screen = (self.config.width as f32, self.config.height as f32);
        let mut verts: Vec<UiVertex> = Vec::new();
        let mut icons: Vec<UiVertex> = Vec::new();

        if self.main_menu {
            ui_rect(&mut verts, 0.0, 0.0, screen.0, screen.1, screen, [0.04, 0.05, 0.08, 1.0]);
            let (ox, oy, s) = self.panel_view();
            let pw = self.hud.w as f32 * s + 56.0;
            let ph = self.hud.h as f32 * s + 56.0;
            ui_rect(&mut verts, ox - 28.0, oy - 28.0, pw, ph, screen, [0.07, 0.08, 0.12, 0.99]);
            ui_rect(&mut verts, ox - 28.0, oy - 28.0, pw, 5.0, screen, [0.55, 0.7, 1.0, 0.95]);
            for r in 1..3usize {
                let by = Self::row_y(oy, s, r);
                ui_rect(&mut verts, ox - 12.0, by, self.hud.w as f32 * s + 24.0, 26.0 * s, screen, [0.13, 0.15, 0.21, 0.95]);
                ui_rect(&mut verts, ox - 12.0, by, 4.0 * s, 26.0 * s, screen, [0.45, 0.6, 0.95, 0.9]);
            }
        } else if self.lib == 2 {
            ui_rect(&mut verts, 0.0, 0.0, screen.0, screen.1, screen, [0.02, 0.02, 0.04, 0.78]);
            let (ox, oy, s) = self.panel_view();
            let pw = self.hud.w as f32 * s + 56.0;
            let ph = self.hud.h as f32 * s + 56.0;
            ui_rect(&mut verts, ox - 28.0, oy - 28.0, pw, ph, screen, [0.07, 0.08, 0.12, 0.97]);
            ui_rect(&mut verts, ox - 28.0, oy - 28.0, pw, 5.0, screen, [0.9, 0.75, 0.4, 0.95]);
            for (i, _) in self.packs.iter().enumerate() {
                let by = Self::row_y(oy, s, i + 1);
                let sel = i == self.pack_sel;
                ui_rect(&mut verts, ox - 12.0, by, self.hud.w as f32 * s + 24.0, 26.0 * s, screen, if sel { [0.28, 0.24, 0.12, 0.98] } else { [0.13, 0.15, 0.21, 0.95] });
                ui_rect(&mut verts, ox - 12.0, by, 4.0 * s, 26.0 * s, screen, [0.9, 0.75, 0.4, 0.95]);
            }
        } else if self.menu_open {
            ui_rect(&mut verts, 0.0, 0.0, screen.0, screen.1, screen, [0.02, 0.02, 0.04, 0.78]);
            let (ox, oy, s) = self.menu_view();
            let pw = self.hud.w as f32 * s + 56.0;
            let ph = self.hud.h as f32 * s + 56.0;
            ui_rect(&mut verts, ox - 28.0, oy - 28.0, pw, ph, screen, [0.07, 0.08, 0.12, 0.97]);
            ui_rect(&mut verts, ox - 28.0, oy - 28.0, pw, 5.0, screen, [0.55, 0.7, 1.0, 0.95]);
            for r in 1..7usize {
                let by = Self::row_y(oy, s, r);
                ui_rect(&mut verts, ox - 12.0, by, self.hud.w as f32 * s + 24.0, 26.0 * s, screen, [0.13, 0.15, 0.21, 0.95]);
                ui_rect(&mut verts, ox - 12.0, by, 4.0 * s, 26.0 * s, screen, [0.45, 0.6, 0.95, 0.9]);
            }
            let row = self.menu_row();
            if row >= 1 && row <= 6 {
                let by = Self::row_y(oy, s, row);
                ui_rect(&mut verts, ox - 12.0, by, self.hud.w as f32 * s + 24.0, 26.0 * s, screen, [0.55, 0.65, 0.95, 0.45]);
            }
        } else if self.mods_open {
            ui_rect(&mut verts, 0.0, 0.0, screen.0, screen.1, screen, [0.02, 0.02, 0.04, 0.72]);
            let (ox, oy, s) = self.panel_view();
            let pw = self.hud.w as f32 * s + 56.0;
            let ph = self.hud.h as f32 * s + 56.0;
            ui_rect(&mut verts, ox - 28.0, oy - 28.0, pw, ph, screen, [0.07, 0.08, 0.12, 0.97]);
            ui_rect(&mut verts, ox - 28.0, oy - 28.0, pw, 5.0, screen, [0.55, 0.85, 0.6, 0.95]);
            let mut line = 2usize;
            for md in blocks::mods() {
                let by = Self::row_y(oy, s, line);
                ui_rect(&mut verts, ox - 12.0, by, self.hud.w as f32 * s + 24.0, 26.0 * s, screen, [0.12, 0.16, 0.15, 0.95]);
                ui_rect(&mut verts, ox - 12.0, by, 4.0 * s, 26.0 * s, screen, [0.45, 0.85, 0.55, 0.95]);
                let mut ix = ox + self.hud.w as f32 * s - 26.0;
                for id in md.ids.iter().take(3) {
                    if let Some(d) = blocks::find(*id) {
                        ui_iso_cube(
                            &mut icons,
                            ix,
                            by + 13.0 * s,
                            11.0 * s,
                            screen,
                            d.tex_top,
                            d.tex_side,
                            if d.tinted { [0.45, 0.72, 0.35] } else { [1.0, 1.0, 1.0] },
                        );
                        ix -= 26.0 * s;
                    }
                }
                line += 1;
                if !md.desc.is_empty() {
                    line += 1;
                }
            }
        }

        let hover = self.hover_name();
        if !hover.is_empty() {
            let tw = self.tip.w as f32;
            let th = self.tip.h as f32;
            let tx = (self.mouse.0 + 16.0).min(screen.0 - tw - 8.0).max(4.0);
            let ty = (self.mouse.1 - th - 12.0).max(4.0);
            ui_rect(&mut verts, tx, ty, tw, th, screen, [0.03, 0.03, 0.05, 0.92]);
        }

        if !self.menu_open && !self.inv_open && !self.chat_open && !self.mods_open {
            let cx = screen.0 / 2.0;
            let cy = screen.1 / 2.0;
            ui_rect(&mut verts, cx - 9.0, cy - 1.0, 18.0, 2.0, screen, [1.0, 1.0, 1.0, 0.75]);
            ui_rect(&mut verts, cx - 1.0, cy - 9.0, 2.0, 18.0, screen, [1.0, 1.0, 1.0, 0.75]);
        }

        let slot = 56.0;
        let gap = 8.0;
        let total = slot * 10.0 + gap * 9.0;
        let hx0 = (screen.0 - total) / 2.0;
        let hy0 = screen.1 - slot - 18.0;
        for i in 0..10usize {
            let x = hx0 + (slot + gap) * i as f32;
            ui_rect(&mut verts, x, hy0, slot, slot, screen, [0.08, 0.08, 0.1, 0.85]);
            if let Some(d) = self.inv.get(i).and_then(|id| blocks::find(*id)) {
                let side_row = d.tex_north;
                ui_iso_cube(
                    &mut icons,
                    x + slot / 2.0,
                    hy0 + slot / 2.0,
                    20.0,
                    screen,
                    d.tex_top,
                    side_row,
                    if d.tinted { [0.45, 0.72, 0.35] } else { [1.0, 1.0, 1.0] },
                );
            }
            if i == self.selected && self.inv_page == 0 {
                ui_rect(&mut verts, x - 2.0, hy0 - 2.0, slot + 4.0, 4.0, screen, [1.0, 1.0, 1.0, 0.9]);
                ui_rect(&mut verts, x - 2.0, hy0 + slot - 2.0, slot + 4.0, 4.0, screen, [1.0, 1.0, 1.0, 0.9]);
                ui_rect(&mut verts, x - 2.0, hy0 - 2.0, 4.0, slot + 4.0, screen, [1.0, 1.0, 1.0, 0.9]);
                ui_rect(&mut verts, x + slot - 2.0, hy0 - 2.0, 4.0, slot + 4.0, screen, [1.0, 1.0, 1.0, 0.9]);
            }
        }

        if self.inv_open {
            let (px, py, w, h) = self.inv_box();
            ui_rect(&mut verts, px, py, w, h, screen, [0.07, 0.08, 0.11, 0.97]);
            ui_rect(&mut verts, px, py, w, 46.0, screen, [0.11, 0.13, 0.19, 1.0]);
            ui_rect(&mut verts, px, py + 46.0, w, 2.0, screen, [0.45, 0.6, 0.95, 0.9]);

            for s in 0..50usize {
                let gi = self.inv_page * 50 + s;
                let (cx, cy) = self.inv_slot_pos(s);
                ui_rect(&mut verts, cx, cy, 62.0, 62.0, screen, [0.1, 0.11, 0.16, 0.98]);
                ui_rect(&mut verts, cx, cy, 62.0, 2.0, screen, [0.18, 0.2, 0.28, 1.0]);
                if let Some(d) = self.inv.get(gi).and_then(|id| blocks::find(*id)) {
                    let side_row = d.tex_north;
                    ui_iso_cube(
                        &mut icons,
                        cx + 31.0,
                        cy + 31.0,
                        27.0,
                        screen,
                        d.tex_top,
                        side_row,
                        if d.tinted { [0.45, 0.72, 0.35] } else { [1.0, 1.0, 1.0] },
                    );
                }
                let col = if self.picked == Some(gi) {
                    [1.0, 0.9, 0.35, 0.95]
                } else if gi == self.selected {
                    [1.0, 1.0, 0.85, 0.9]
                } else {
                    [0.0, 0.0, 0.0, 0.0]
                };
                if col[3] > 0.0 {
                    ui_rect(&mut verts, cx - 2.0, cy - 2.0, 66.0, 3.0, screen, col);
                    ui_rect(&mut verts, cx - 2.0, cy + 61.0, 66.0, 3.0, screen, col);
                    ui_rect(&mut verts, cx - 2.0, cy - 2.0, 3.0, 66.0, screen, col);
                    ui_rect(&mut verts, cx + 61.0, cy - 2.0, 3.0, 66.0, screen, col);
                }
            }

            if let Some(p) = self.picked {
                if let Some(d) = self.inv.get(p).and_then(|id| blocks::find(*id)) {
                    let (mx, my) = self.mouse;
                    ui_iso_cube(
                        &mut icons,
                        mx,
                        my,
                        22.0,
                        screen,
                        d.tex_top,
                        d.tex_side,
                        if d.tinted { [0.45, 0.72, 0.35] } else { [1.0, 1.0, 1.0] },
                    );
                }
            }

            let pages = (self.inv.len() + 49) / 50;
            let bx = px + 160.0;
            let by = py + 84.0 + 5.0 * 68.0 + 10.0;
            ui_rect(&mut verts, bx, by, 70.0, 26.0, screen, [0.16, 0.18, 0.26, 0.95]);
            ui_rect(&mut verts, bx + 5.0, by + 13.0, 16.0, 4.0, screen, [0.85, 0.88, 1.0, 0.9]);
            ui_rect(&mut verts, bx + 5.0, by + 9.0, 10.0, 4.0, screen, [0.85, 0.88, 1.0, 0.6]);
            ui_rect(&mut verts, bx + 610.0, by, 70.0, 26.0, screen, [0.16, 0.18, 0.26, 0.95]);
            ui_rect(&mut verts, bx + 635.0, by + 13.0, 16.0, 4.0, screen, [0.85, 0.88, 1.0, 0.9]);
            ui_rect(&mut verts, bx + 641.0, by + 9.0, 10.0, 4.0, screen, [0.85, 0.88, 1.0, 0.6]);
            let bar = 600.0f32;
            let frac = if pages > 1 {
                (self.inv_page + 1) as f32 / pages as f32
            } else {
                1.0
            };
            ui_rect(&mut verts, bx + 86.0, by + 11.0, bar - 86.0, 4.0, screen, [0.2, 0.22, 0.3, 0.9]);
            ui_rect(&mut verts, bx + 86.0, by + 11.0, (bar - 86.0) * frac, 4.0, screen, [0.55, 0.7, 1.0, 0.9]);
        }

        self.queue.write_buffer(&self.ui_buffer, 0, bytemuck::cast_slice(&verts));
        if !icons.is_empty() {
            let off = (std::mem::size_of::<UiVertex>() * verts.len()) as u64;
            self.queue.write_buffer(&self.ui_buffer, off, bytemuck::cast_slice(&icons));
        }
        (verts.len() as u32, icons.len() as u32, 0)
    }

    fn break_block(&mut self) {
        let p = self.snd.dig.clone();
        self.snd.play(&p);
        let dir = Vec3::new(
            self.camera.yaw.sin() * self.camera.pitch.cos(),
            self.camera.pitch.sin(),
            self.camera.yaw.cos() * self.camera.pitch.cos(),
        );
        let mut p = self.camera.pos;
        let step = 0.08;
        for _ in 0..140 {
            p += dir * step;
            let x = p.x.floor() as i32;
            let y = p.y.floor() as i32;
            let z = p.z.floor() as i32;
            if x < 0 || z < 0 || y < 0 || x >= WORLD as i32 || z >= WORLD as i32 || y >= HEIGHT as i32 {
                return;
            }
            if self.blocks[idx(x as usize, y as usize, z as usize)] != AIR {
                self.blocks[idx(x as usize, y as usize, z as usize)] = AIR;
                let cx = x as usize / CHUNK;
                let cz = z as usize / CHUNK;
                let ci = cz * CHUNKS + cx;
                self.rebuild_chunk(ci);
                if x as usize % CHUNK == 0 && cx > 0 {
                    self.rebuild_chunk(ci - 1);
                }
                if x as usize % CHUNK == CHUNK - 1 && cx + 1 < CHUNKS {
                    self.rebuild_chunk(ci + 1);
                }
                if z as usize % CHUNK == 0 && cz > 0 {
                    self.rebuild_chunk(ci - CHUNKS);
                }
                if z as usize % CHUNK == CHUNK - 1 && cz + 1 < CHUNKS {
                    self.rebuild_chunk(ci + CHUNKS);
                }
                return;
            }
        }
    }

    fn regenerate(&mut self) {
        self.seed += 1;
        self.blocks = build_world(self.seed);
        self.rebuild_all();
    }

    fn resize(&mut self, width: u32, height: u32) {
        if width == 0 || height == 0 {
            return;
        }
        self.config.width = width;
        self.config.height = height;
        self.surface.configure(&self.device, &self.config);
        self.depth_view = create_depth(&self.device, &self.config);
    }

    fn view_proj(&self) -> Mat4 {
        let aspect = self.config.width as f32 / self.config.height as f32;
        let proj = Mat4::perspective_rh(70f32.to_radians(), aspect, 0.05, 300.0);
        let dir = Vec3::new(
            self.camera.yaw.sin() * self.camera.pitch.cos(),
            self.camera.pitch.sin(),
            self.camera.yaw.cos() * self.camera.pitch.cos(),
        );
        let (eye, target) = match self.cam_mode {
            1 => (self.camera.pos - dir * 3.0, self.camera.pos + dir * 1.5),
            2 => (self.camera.pos + dir * 3.0, self.camera.pos),
            _ => (self.camera.pos, self.camera.pos + dir),
        };
        let view = Mat4::look_at_rh(eye, target, Vec3::Y);
        proj * view
    }

    fn update(&mut self, dt: f32) {
        let hover = self.hover_name();
        if hover != self.tip.name {
            self.tip.name = hover.clone();
            let data = rasterize_text(&[hover], &self.font, self.tip.w as usize, self.tip.h as usize);
            self.queue.write_texture(
                wgpu::ImageCopyTexture {
                    texture: &self.tip.texture,
                    mip_level: 0,
                    origin: wgpu::Origin3d::ZERO,
                    aspect: wgpu::TextureAspect::All,
                },
                &data,
                wgpu::ImageDataLayout {
                    offset: 0,
                    bytes_per_row: Some(4 * self.tip.w),
                    rows_per_image: Some(self.tip.h),
                },
                wgpu::Extent3d { width: self.tip.w, height: self.tip.h, depth_or_array_layers: 1 },
            );
        }

        if self.do_cycle && !self.menu_open {
            self.time_of_day = (self.time_of_day + dt / self.day_len) % 1.0;
        }

        if self.main_menu {
            self.camera.vel = Vec3::ZERO;
            self.update_hud_text();
            let sd = self.sun_dir();
            let u = Uniforms {
                view_proj: self.view_proj().to_cols_array_2d(),
                light: [sd.x, sd.y, sd.z, self.shader_mode as f32],
            };
            self.queue.write_buffer(&self.uniform_buffer, 0, bytemuck::bytes_of(&u));
            return;
        }

        let speed = 9.0;
        let forward = Vec3::new(self.camera.yaw.sin(), 0.0, self.camera.yaw.cos());
        let right = Vec3::new(-forward.z, 0.0, forward.x);

        let mut dir = Vec3::ZERO;
        if self.keys[0] { dir += forward; }
        if self.keys[1] { dir -= forward; }
        if self.keys[2] { dir -= right; }
        if self.keys[3] { dir += right; }

        if self.menu_open || self.inv_open || self.chat_open || self.main_menu {
            dir = Vec3::ZERO;
        }

        if self.main_menu {
            self.camera.yaw += dt * 0.10;
            self.camera.pitch = -0.12;
            self.camera.vel = Vec3::ZERO;
        }

        let ground = self.hits(self.camera.pos - Vec3::Y * 0.08);
        if self.flying {
            let mut vy = 0.0f32;
            if self.keys[4] {
                vy += 8.0;
            }
            if self.keys[5] {
                vy -= 8.0;
            }
            self.camera.vel.y = vy;
        } else {
            if self.keys[4] && ground && !self.menu_open && !self.inv_open && !self.chat_open {
                self.camera.vel.y = 7.4;
            }
            self.camera.vel.y = (self.camera.vel.y - 22.0 * dt).max(-40.0);
        }

        if dir.length_squared() > 0.0 {
            let step = dir.normalize() * speed * dt;
            let nx = self.camera.pos + Vec3::new(step.x, 0.0, 0.0);
            if !self.hits(nx) {
                self.camera.pos = nx;
            }
            let nz = self.camera.pos + Vec3::new(0.0, 0.0, step.z);
            if !self.hits(nz) {
                self.camera.pos = nz;
            }
        }

        if self.hits(self.camera.pos) {
            for _ in 0..40 {
                self.camera.pos.y += 0.25;
                if !self.hits(self.camera.pos) {
                    break;
                }
            }
            self.camera.vel.y = 0.0;
        }

        let ny = self.camera.pos + Vec3::new(0.0, self.camera.vel.y * dt, 0.0);
        if self.hits(ny) {
            if self.camera.vel.y < 0.0 {
                let feet = (ny.y - 1.75).ceil();
                self.camera.pos.y = feet + 1.75;
            }
            self.camera.vel.y = 0.0;
        } else {
            self.camera.pos = ny;
        }

        if dir.length_squared() > 0.0 && self.keys[4] == false {
            self.step_timer -= dt;
            if self.step_timer <= 0.0 && self.hits(self.camera.pos - Vec3::Y * 0.1) {
                self.step_timer = 0.42;
                let p = self.snd.step.clone();
                self.snd.play(&p);
            }
        }

        if dt > 0.0 {
            let inst = 1.0 / dt;
            self.fps = if self.fps <= 0.0 { inst } else { self.fps * 0.95 + inst * 0.05 };
        }
        if self.hud_enabled || self.mods_open || self.menu_open || self.chat_open || self.lib == 2 || self.main_menu {
            self.hud_timer -= dt;
            if self.hud_timer <= 0.0 {
                self.hud_timer = 0.25;
                self.update_hud_text();
            }
        }

        let sd = self.sun_dir();
        let u = Uniforms {
            view_proj: self.view_proj().to_cols_array_2d(),
            light: [sd.x, sd.y, sd.z, self.shader_mode as f32],
        };
        self.queue.write_buffer(&self.uniform_buffer, 0, bytemuck::bytes_of(&u));
    }

    fn render(&mut self) {
        let sky = self.sky_color();
        let frame = match self.surface.get_current_texture() {
            Ok(f) => f,
            Err(_) => return,
        };
        let view = frame.texture.create_view(&wgpu::TextureViewDescriptor::default());
        let mut encoder = self.device.create_command_encoder(&wgpu::CommandEncoderDescriptor { label: None });

        {
            let mut pass = encoder.begin_render_pass(&wgpu::RenderPassDescriptor {
                label: Some("world pass"),
                color_attachments: &[Some(wgpu::RenderPassColorAttachment {
                    view: &view,
                    resolve_target: None,
                    ops: wgpu::Operations {
                        load: wgpu::LoadOp::Clear(wgpu::Color { r: sky[0], g: sky[1], b: sky[2], a: 1.0 }),
                        store: wgpu::StoreOp::Store,
                    },
                })],
                depth_stencil_attachment: Some(wgpu::RenderPassDepthStencilAttachment {
                    view: &self.depth_view,
                    depth_ops: Some(wgpu::Operations {
                        load: wgpu::LoadOp::Clear(1.0),
                        store: wgpu::StoreOp::Store,
                    }),
                    stencil_ops: None,
                }),
                occlusion_query_set: None,
                timestamp_writes: None,
            });

            pass.set_pipeline(&self.pipeline);
            pass.set_bind_group(0, &self.bind_group, &[]);

            let cam = self.camera.pos;
            let sun_dir = self.sun_dir();
            let moon_dir = -sun_dir;
            let night = (-sun_dir.y * 2.0).clamp(0.0, 1.0);
            let mut sverts: Vec<Vertex> = Vec::with_capacity(400);
            let mut push_quad = |c: Vec3, d: Vec3, size: f32, row: f32, color: [f32; 3], out: &mut Vec<Vertex>| {
                let right = if d.cross(Vec3::Y).length_squared() < 0.0001 {
                    Vec3::X
                } else {
                    d.cross(Vec3::Y).normalize()
                };
                let up = right.cross(d).normalize();
                let corners = [
                    (c - right * size + up * size, [0.0f32, 0.0]),
                    (c + right * size + up * size, [1.0, 0.0]),
                    (c + right * size - up * size, [1.0, 1.0]),
                    (c - right * size - up * size, [0.0, 1.0]),
                ];
                for i in [0usize, 1, 2, 0, 2, 3] {
                    let (p, uv) = corners[i];
                    out.push(Vertex {
                        pos: [p.x, p.y, p.z],
                        normal: [0.0, 1.0, 0.0],
                        uv: [uv[0], (row + uv[1]) / TEX_ROWS as f32],
                        color,
                    });
                }
            };

            if sun_dir.y > -0.15 {
                push_quad(cam + sun_dir * 250.0, sun_dir, 34.0, 15.0, [1.0, 1.0, 1.0], &mut sverts);
            }
            if moon_dir.y > -0.15 {
                push_quad(cam + moon_dir * 250.0, moon_dir, 26.0, 14.0, [0.85, 0.9, 1.0], &mut sverts);
            }
            if night > 0.05 {
                for i in 0..48 {
                    let h1 = hash2(i * 7 + 3, 11);
                    let h2 = hash2(i * 13 + 5, 29);
                    let a = h1 * std::f32::consts::TAU;
                    let z = h2 * 2.0 - 1.0;
                    let r = (1.0 - z * z).max(0.0).sqrt();
                    let d = Vec3::new(r * a.cos(), z, r * a.sin());
                    if d.y < 0.02 {
                        continue;
                    }
                    push_quad(cam + d * 280.0, d, 3.0, 13.0, [night, night, night], &mut sverts);
                }
            }
            self.queue.write_buffer(&self.sun_buffer, 0, bytemuck::cast_slice(&sverts));
            pass.set_pipeline(&self.sky_pipeline);
            pass.set_vertex_buffer(0, self.sun_buffer.slice(..));
            pass.draw(0..sverts.len() as u32, 0..1);
            pass.set_pipeline(&self.pipeline);

            if self.cam_mode != 0 {
                let yaw = self.camera.yaw;
                let base = self.camera.pos - Vec3::Y * 1.72;
                let model = player_verts(base, yaw);
                self.queue.write_buffer(&self.player_buffer, 0, bytemuck::cast_slice(&model));
                pass.set_pipeline(&self.player_pipeline);
                pass.set_bind_group(0, &self.player_bind, &[]);
                pass.set_vertex_buffer(0, self.player_buffer.slice(..));
                pass.draw(0..model.len() as u32, 0..1);
                pass.set_pipeline(&self.pipeline);
                pass.set_bind_group(0, &self.bind_group, &[]);
            }

            for chunk in &self.chunks {
                if chunk.count == 0 {
                    continue;
                }
                if chunk.center.distance(cam) > self.view_dist() {
                    continue;
                }
                pass.set_vertex_buffer(0, chunk.buffer.slice(..));
                pass.draw(0..chunk.count, 0..1);
            }
        }

        {
            let (ui_rects, ui_icons, ui_skin) = self.build_ui();
            let mut pass = encoder.begin_render_pass(&wgpu::RenderPassDescriptor {
                label: Some("ui pass"),
                color_attachments: &[Some(wgpu::RenderPassColorAttachment {
                    view: &view,
                    resolve_target: None,
                    ops: wgpu::Operations {
                        load: wgpu::LoadOp::Load,
                        store: wgpu::StoreOp::Store,
                    },
                })],
                depth_stencil_attachment: None,
                occlusion_query_set: None,
                timestamp_writes: None,
            });
            pass.set_pipeline(&self.ui_pipeline);
            pass.set_bind_group(0, &self.ui_bind_white, &[]);
            pass.set_vertex_buffer(0, self.ui_buffer.slice(..));
            pass.draw(0..ui_rects, 0..1);
            if ui_icons > 0 {
                pass.set_bind_group(0, &self.ui_bind_atlas, &[]);
                pass.draw(ui_rects..ui_rects + ui_icons, 0..1);
            }
            if ui_skin > 0 {
                pass.set_bind_group(0, &self.ui_bind_skin, &[]);
                let skin_start = ui_rects + ui_icons;
                pass.draw(skin_start..skin_start + ui_skin, 0..1);
            }
        }

        if !self.tip.name.is_empty() && self.menu_open() {
            let tw = self.tip.w as f32;
            let th = self.tip.h as f32;
            let tx = (self.mouse.0 + 16.0).min(self.config.width as f32 - tw - 8.0).max(4.0);
            let ty = (self.mouse.1 - th - 12.0).max(4.0);
            let quad = hud_quad_at(tx, ty, tw, th, self.config.width, self.config.height);
            self.queue.write_buffer(&self.tip.buffer, 0, bytemuck::cast_slice(&quad));
            let mut pass = encoder.begin_render_pass(&wgpu::RenderPassDescriptor {
                label: Some("tip pass"),
                color_attachments: &[Some(wgpu::RenderPassColorAttachment {
                    view: &view,
                    resolve_target: None,
                    ops: wgpu::Operations {
                        load: wgpu::LoadOp::Load,
                        store: wgpu::StoreOp::Store,
                    },
                })],
                depth_stencil_attachment: None,
                occlusion_query_set: None,
                timestamp_writes: None,
            });
            pass.set_pipeline(&self.hud.pipeline);
            pass.set_bind_group(0, &self.tip.bind, &[]);
            pass.set_vertex_buffer(0, self.tip.buffer.slice(..));
            pass.draw(0..6, 0..1);
        }

        if self.hud_enabled || self.mods_open || self.menu_open || self.chat_open || self.lib == 2 || self.main_menu {
            let quad = if self.menu_open || self.mods_open || self.lib == 2 || self.main_menu {
                let (ox, oy, s) = if self.menu_open {
                    self.menu_view()
                } else {
                    self.panel_view()
                };
                hud_quad_at(ox, oy, self.hud.w as f32 * s, self.hud.h as f32 * s, self.config.width, self.config.height)
            } else {
                hud_quad(
                    self.config.width,
                    self.config.height,
                    self.hud.w as f32,
                    self.hud.h as f32,
                )
            };
            self.queue.write_buffer(&self.hud.buffer, 0, bytemuck::cast_slice(&quad));

            let mut pass = encoder.begin_render_pass(&wgpu::RenderPassDescriptor {
                label: Some("hud pass"),
                color_attachments: &[Some(wgpu::RenderPassColorAttachment {
                    view: &view,
                    resolve_target: None,
                    ops: wgpu::Operations {
                        load: wgpu::LoadOp::Load,
                        store: wgpu::StoreOp::Store,
                    },
                })],
                depth_stencil_attachment: None,
                occlusion_query_set: None,
                timestamp_writes: None,
            });
            pass.set_pipeline(&self.hud.pipeline);
            pass.set_bind_group(0, &self.hud.bind, &[]);
            pass.set_vertex_buffer(0, self.hud.buffer.slice(..));
            pass.draw(0..6, 0..1);
        }

        self.queue.submit(Some(encoder.finish()));
        frame.present();
    }

    fn update_hud_text(&mut self) {
        let lines = if self.main_menu {
            self.menu_lines()
        } else if self.lib == 2 {
            self.lib_lines()
        } else if self.chat_open {
            let mut v: Vec<String> = Vec::new();
            let start = self.chat_log.len().saturating_sub(6);
            for l in &self.chat_log[start..] {
                v.push(l.clone());
            }
            v.push(format!("> {}_", self.chat_input));
            v
        } else if self.menu_open {
            self.menu_lines()
        } else if self.mods_open {
            let mods = blocks::mods();
            let mut v = vec![
                String::from("MODS"),
                format!("{} шт.   M - close   F3 - info", mods.len()),
            ];
            if mods.is_empty() {
                v.push(String::from("папка mods пустая"));
            }
            for md in mods {
                v.push(format!("{}   v{}", md.name, md.ver));
                if !md.desc.is_empty() {
                    v.push(format!("  {}", md.desc));
                }
            }
            v
        } else {
        let lines = vec![
            format!("FPS: {:.0}", self.fps),
            format!("XYZ: {:.1} {:.1} {:.1}", self.camera.pos.x, self.camera.pos.y, self.camera.pos.z),
            format!("CHUNKS: {}  SEED: {}", CHUNKS * CHUNKS, self.seed),
            format!("BLOCK: {}", self.inv.get(self.selected).and_then(|id| blocks::find(*id)).map(|d| d.name.clone()).unwrap_or_default()),
            String::from("F3 - hide  LMB - break  RMB - place  E - inventory  M - mods  R - new world"),
        ];
        lines
        };
        let data = rasterize_text(&lines, &self.font, self.hud.w as usize, self.hud.h as usize);
        self.queue.write_texture(
            wgpu::ImageCopyTexture {
                texture: &self.hud.texture,
                mip_level: 0,
                origin: wgpu::Origin3d::ZERO,
                aspect: wgpu::TextureAspect::All,
            },
            &data,
            wgpu::ImageDataLayout {
                offset: 0,
                bytes_per_row: Some(4 * self.hud.w),
                rows_per_image: Some(self.hud.h),
            },
            wgpu::Extent3d { width: self.hud.w, height: self.hud.h, depth_or_array_layers: 1 },
        );
    }

    fn set_key(&mut self, code: KeyCode, pressed: bool) {
        match code {
            KeyCode::KeyW => self.keys[0] = pressed,
            KeyCode::KeyS => self.keys[1] = pressed,
            KeyCode::KeyA => self.keys[2] = pressed,
            KeyCode::KeyD => self.keys[3] = pressed,
            KeyCode::Space => {
                self.keys[4] = pressed;
                if pressed {
                    let now = std::time::Instant::now();
                    let dbl = self
                        .last_space
                        .map(|t| now.duration_since(t).as_secs_f32() < 0.35)
                        .unwrap_or(false);
                    if dbl {
                        self.flying = !self.flying;
                        self.camera.vel.y = 0.0;
                        self.last_space = None;
                    } else {
                        self.last_space = Some(now);
                    }
                }
            }
            KeyCode::ControlLeft | KeyCode::ShiftLeft => self.keys[5] = pressed,
            KeyCode::KeyR if pressed => self.regenerate(),
            KeyCode::F5 if pressed => self.cam_mode = (self.cam_mode + 1) % 3,
            KeyCode::Digit1 if pressed => self.selected = 0,
            KeyCode::Digit2 if pressed => self.selected = 1,
            KeyCode::Digit3 if pressed => self.selected = 2,
            KeyCode::Digit4 if pressed => self.selected = 3,
            KeyCode::Digit5 if pressed => self.selected = 4,
            KeyCode::Digit6 if pressed => self.selected = 5,
            KeyCode::Digit7 if pressed => self.selected = 6,
            KeyCode::Digit8 if pressed => self.selected = 7,
            KeyCode::Digit9 if pressed => self.selected = 8,
            KeyCode::Digit0 if pressed => self.selected = 9,
            KeyCode::KeyM if pressed && !self.menu_open => {
                self.mods_open = !self.mods_open;
                self.hud_timer = 0.0;
                self.set_menu_cursor();
            }
            KeyCode::KeyT if pressed => {
                self.chat_open = true;
                self.chat_input.clear();
                self.keys = [false; 6];
                self.hud_timer = 0.0;
            }
            KeyCode::Slash if pressed => {
                self.chat_open = true;
                self.chat_input = String::from("/");
                self.keys = [false; 6];
                self.hud_timer = 0.0;
            }
            KeyCode::ArrowRight if pressed && self.inv_open => {
                let pages = (self.inv.len() + 49) / 50;
                if pages > 1 {
                    self.inv_page = (self.inv_page + 1) % pages;
                }
            }
            KeyCode::ArrowLeft if pressed && self.inv_open => {
                let pages = (self.inv.len() + 49) / 50;
                if pages > 1 {
                    self.inv_page = (self.inv_page + pages - 1) % pages;
                }
            }
            KeyCode::KeyE if pressed && !self.menu_open => {
                self.inv_open = !self.inv_open;
                self.hud_timer = 0.0;
                self.set_menu_cursor();
            }
            KeyCode::F3 if pressed => {
                self.hud_enabled = !self.hud_enabled;
                if self.hud_enabled {
                    self.hud_timer = 0.0;
                }
            }
            KeyCode::F11 if pressed => {
                self.fullscreen = !self.fullscreen;
                self.window.set_fullscreen(if self.fullscreen {
                    Some(Fullscreen::Borderless(None))
                } else {
                    None
                });
            }
            _ => {}
        }
    }
}

fn grab_cursor(window: &Window) {
    if window.set_cursor_grab(CursorGrabMode::Locked).is_err() {
        let _ = window.set_cursor_grab(CursorGrabMode::Confined);
    }
    window.set_cursor_visible(false);
}

fn create_depth(device: &wgpu::Device, config: &wgpu::SurfaceConfiguration) -> wgpu::TextureView {
    let texture = device.create_texture(&wgpu::TextureDescriptor {
        label: Some("depth"),
        size: wgpu::Extent3d { width: config.width, height: config.height, depth_or_array_layers: 1 },
        mip_level_count: 1,
        sample_count: 1,
        dimension: wgpu::TextureDimension::D2,
        format: DEPTH_FORMAT,
        usage: wgpu::TextureUsages::RENDER_ATTACHMENT,
        view_formats: &[],
    });
    texture.create_view(&wgpu::TextureViewDescriptor::default())
}

fn create_world_pipeline(
    device: &wgpu::Device,
    layout: &wgpu::PipelineLayout,
    format: wgpu::TextureFormat,
    shader: &wgpu::ShaderModule,
) -> wgpu::RenderPipeline {
    device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
        label: Some("world pipeline"),
        layout: Some(layout),
        vertex: wgpu::VertexState {
            module: shader,
            entry_point: "vs_main",
            buffers: &[wgpu::VertexBufferLayout {
                array_stride: std::mem::size_of::<Vertex>() as u64,
                step_mode: wgpu::VertexStepMode::Vertex,
                attributes: &wgpu::vertex_attr_array![0 => Float32x3, 1 => Float32x3, 2 => Float32x2, 3 => Float32x3],
            }],
            compilation_options: Default::default(),
        },
        fragment: Some(wgpu::FragmentState {
            module: shader,
            entry_point: "fs_main",
            targets: &[Some(wgpu::ColorTargetState {
                format,
                blend: None,
                write_mask: wgpu::ColorWrites::ALL,
            })],
            compilation_options: Default::default(),
        }),
        primitive: wgpu::PrimitiveState {
            cull_mode: Some(wgpu::Face::Back),
            ..Default::default()
        },
        depth_stencil: Some(wgpu::DepthStencilState {
            format: DEPTH_FORMAT,
            depth_write_enabled: true,
            depth_compare: wgpu::CompareFunction::Less,
            stencil: wgpu::StencilState::default(),
            bias: wgpu::DepthBiasState::default(),
        }),
        multisample: wgpu::MultisampleState::default(),
        multiview: None,
    })
}

fn scan_packs() -> Vec<(String, String, std::path::PathBuf)> {
    let mut out = Vec::new();
    for d in blocks::candidate_roots() {
        let p = d.join("shaders");
        let rd = match std::fs::read_dir(&p) {
            Ok(r) => r,
            Err(_) => continue,
        };
        let mut dirs: Vec<_> = rd.flatten().collect();
        dirs.sort_by_key(|e| e.file_name());
        for e in dirs {
            let dir = e.path();
            if !dir.is_dir() {
                continue;
            }
            let mut name = dir
                .file_name()
                .map(|s| s.to_string_lossy().to_string())
                .unwrap_or_default();
            let mut desc = String::new();
            let mut ver = String::new();
            for meta in ["shader.json", "shader.txt"] {
                if let Ok(t) = std::fs::read_to_string(dir.join(meta)) {
                    for line in t.lines() {
                        let l = line.trim().trim_start_matches('#').trim();
                        let mut kv = l.splitn(2, '=');
                        let k = kv.next().unwrap_or("").trim().to_lowercase();
                        let v = kv.next().unwrap_or("").trim().trim_matches('"').to_string();
                        match k.as_str() {
                            "shader_name" => name = v,
                            "shader_desc" => desc = v,
                            "shader_ver" => ver = v,
                            _ => {}
                        }
                    }
                }
            }
            if !ver.is_empty() {
                desc = format!("v{}  {}", ver, desc).trim().to_string();
            }
            out.push((name, desc, dir.join("shader.wgsl")));
        }
        break;
    }
    out
}

fn shader_src(file: &str, fallback: &str) -> String {
    if true { return fallback.to_string(); }
    for d in blocks::candidate_roots() {
        let p = d.join("shaders").join(format!("{}.wgsl", file));
        if let Ok(t) = std::fs::read_to_string(&p) {
            return t;
        }
    }
    fallback.to_string()
}

fn main() {
    std::panic::set_hook(Box::new(|info| {
        let _ = std::fs::write("panic.txt", format!("{}", info));
    }));

    let event_loop = EventLoop::new().unwrap();
    event_loop.set_control_flow(ControlFlow::Poll);

    let window = Arc::new(
        WindowBuilder::new()
            .with_title("Cubistic")
            .with_inner_size(LogicalSize::new(1280.0, 720.0))
            .build(&event_loop)
            .unwrap(),
    );

    let mut state = pollster::block_on(State::new(window.clone()));
    state.load_lang();
    state.refresh_worlds();
    state.set_menu_cursor();
    let mut last = std::time::Instant::now();

    event_loop
        .run(move |event, elwt| match event {
            Event::WindowEvent { window_id, ref event } if window_id == state.window.id() => match event {
                WindowEvent::CloseRequested => {
                    state.save_world();
                    elwt.exit();
                }
                WindowEvent::Focused(true) => state.set_menu_cursor(),
                WindowEvent::Resized(size) => state.resize(size.width, size.height),
                WindowEvent::KeyboardInput { event, .. } => {
                    if let PhysicalKey::Code(code) = event.physical_key {
                        if state.chat_open {
                            if event.state == ElementState::Pressed {
                                match code {
                                    KeyCode::Escape => {
                                        state.chat_open = false;
                                        state.chat_input.clear();
                                        state.hud_timer = 0.0;
                                    }
                                    KeyCode::Enter | KeyCode::NumpadEnter => state.submit_chat(),
                                    KeyCode::Backspace => {
                                        state.chat_input.pop();
                                        state.hud_timer = 0.0;
                                    }
                                    _ => {
                                        if let Some(t) = event.text.clone() {
                                            for ch in t.chars() {
                                                if !ch.is_control() {
                                                    state.chat_input.push(ch);
                                                }
                                            }
                                            state.hud_timer = 0.0;
                                        }
                                    }
                                }
                            }
                        } else {
                        state.set_key(code, event.state == ElementState::Pressed);
                        }
                        if !state.chat_open
                            && event.state == ElementState::Pressed
                            && event.text.as_deref() == Some("/")
                        {
                            state.chat_open = true;
                            state.chat_input = String::from("/");
                            state.keys = [false; 6];
                            state.hud_timer = 0.0;
                        }
                        if !state.chat_open && !state.main_menu && code == KeyCode::Escape && event.state == ElementState::Pressed {
                            if state.inv_open || state.mods_open || state.lib != 0 {
                                state.inv_open = false;
                                state.mods_open = false;
                                state.lib = 0;
                                state.menu_open = false;
                            } else {
                                state.menu_open = !state.menu_open;
                            }
                            state.hud_timer = 0.0;
                            state.set_menu_cursor();
                        }
                    }
                }
                WindowEvent::CursorMoved { position, .. } => {
                    state.mouse = (position.x as f32, position.y as f32);
                }
                WindowEvent::MouseInput { state: st, button: MouseButton::Left, .. } => {
                    if *st == ElementState::Released && state.inv_open {
                        state.inv_release();
                    }
                    if *st == ElementState::Pressed {
                        if state.lib != 0 {
                            state.lib_click();
                        } else if state.main_menu || state.menu_open {
                            state.menu_click(state.menu_row());
                        } else if state.inv_open {
                            state.pick_in_inventory();
                        } else if !state.mods_open {
                            state.break_block();
                        }
                    }
                }
                WindowEvent::MouseInput { state: st, button: MouseButton::Right, .. } => {
                    if *st == ElementState::Pressed && !state.inv_open && !state.mods_open && !state.menu_open {
                        state.place_block();
                    }
                }
                WindowEvent::RedrawRequested => {
                    let now = std::time::Instant::now();
                    let dt = now.duration_since(last).as_secs_f32().min(0.05);
                    last = now;
                    state.update(dt);
                    state.render();
                    state.window.request_redraw();
                }
                _ => {}
            },
            Event::DeviceEvent {
                event: DeviceEvent::MouseMotion { delta },
                ..
            } => {
                if !state.inv_open && !state.mods_open && !state.menu_open && !state.main_menu {
                    state.camera.yaw -= delta.0 as f32 * 0.0025;
                    state.camera.pitch = (state.camera.pitch - delta.1 as f32 * 0.0025).clamp(-1.5, 1.5);
                }
            }
            _ => {}
        })
        .unwrap();
}
