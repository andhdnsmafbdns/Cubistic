# Cubistic

Cubistic - игра, похожая на майнкрафт, но на RUST. Здесь можно строить миры и делать моды

Версия: **26.0.0-dev**.

## Управление

WASD/ЦФЫВ - ходьба
Пробел - прыжок
ЛКМ - сломать блок
ПКМ - поставить блок
1;2;3;4;5;6;7;8;9;0 - хотбар
E/У - инвентарь
ESC - меню
R/К - не нажимай чел
F3 - фпс и ещё че-то

## Команды

- `/time set day|night|noon|midnight|<0-24>`
- `/time add <секунды>`
- `/gamerule doDaylightCycle true|false`
- `/help`

## Формат блока

```
id:grass
name:Grass
break_time:0.6s
tool:shovel
rank:wood
[Texture]
top:grass
bottom:dirt
north:grass_side
south:grass_side
east:grass_side
west:grass_side
```

Текстуры ищутся в `game\images\blocks\<имя>.png`. Незнакомые имена тоже подхватываются как файлы.

## Лицензия

MIT, 2026, andhdnsmafbdns. См. файл `LICENSE`.
