﻿id:oak_leaves
name: Oak leaves
break_time:0.2s
tool:axe
rank:wood
[Texture]
top:oak_leaves
side:oak_leaves
bottom:oak_leaves
