use std::path::{Path, PathBuf};
use std::sync::OnceLock;

pub const ATLAS_ROWS: usize = 16;

pub struct BlockDef {
    pub id: u8,
    pub key: String,
    pub name: String,
    pub break_time: f32,
    pub tool: String,
    pub rank: String,
    pub tex_top: u8,
    pub tex_side: u8,
    pub tex_bottom: u8,
    pub tex_north: u8,
    pub tex_south: u8,
    pub tex_east: u8,
    pub tex_west: u8,
    pub tinted: bool,
}

pub struct ModInfo {
    pub name: String,
    pub id: String,
    pub desc: String,
    pub ver: String,
    pub blocks: u32,
    pub ids: Vec<u8>,
}

pub struct ModTex {
    pub row: u8,
    pub path: Option<PathBuf>,
    pub color: [u8; 3],
}

fn tex_row(name: &str) -> Option<u8> {
    match name.trim() {
        "grass" => Some(0),
        "grass_side" => Some(1),
        "dirt" => Some(2),
        "stone" => Some(3),
        "oak_wood" => Some(4),
        "oak_wood_up" => Some(5),
        _ => None,
    }
}

fn base_id(key: &str) -> Option<u8> {
    match key {
        "grass" => Some(1),
        "dirt" => Some(2),
        "stone" => Some(3),
        "wood" | "oak_wood" => Some(4),
        _ => None,
    }
}

fn candidates() -> Vec<PathBuf> {
    let exe = std::env::current_exe()
        .ok()
        .and_then(|p| p.parent().map(|p| p.to_path_buf()))
        .unwrap_or_else(|| PathBuf::from("."));

    let mut v: Vec<PathBuf> = Vec::new();
    v.push(exe.join("game"));
    v.push(exe.clone());
    if let Some(parent) = exe.parent() {
        v.push(parent.join("game"));
        v.push(parent.to_path_buf());
    }
    v.push(PathBuf::from("."));
    v
}

pub fn candidate_roots() -> Vec<PathBuf> {
    candidates()
}

fn find_dir(name: &str) -> Option<PathBuf> {
    for c in candidates() {
        let p = c.join(name);
        if p.is_dir() {
            return Some(p);
        }
    }
    None
}

fn tex_for(v: &str, root: &Path, tex: &mut Vec<ModTex>, fallback: u8) -> u8 {
    if let Some(r) = tex_row(v) {
        return r;
    }
    let name = v.trim();
    if name.is_empty() {
        return fallback;
    }
    let mut cands: Vec<PathBuf> = Vec::new();
    if name.ends_with(".png") {
        cands.push(root.join(name));
    }
    cands.push(root.join("images").join("blocks").join(format!("{}.png", name)));
    cands.push(root.join("images").join(format!("{}.png", name)));
    cands.push(root.join("images").join("icon.png"));
    for c in cands {
        if !c.is_file() {
            continue;
        }
        if let Some(t) = tex.iter().find(|t| t.path.as_deref() == Some(c.as_path())) {
            return t.row;
        }
        let row = 6u8 + tex.len() as u8;
        if (row as usize) >= ATLAS_ROWS {
            return fallback;
        }
        tex.push(ModTex { row, path: Some(c), color: [200, 120, 220] });
        return row;
    }
    fallback
}

fn parse_file(
    path: &Path,
    root: &Path,
    out: &mut Vec<BlockDef>,
    next_id: &mut u8,
    tex: &mut Vec<ModTex>,
) {
    let text = match std::fs::read_to_string(path) {
        Ok(t) => t,
        Err(_) => return,
    };

    let mut has_section = false;
    let mut key = String::new();
    let mut name = String::new();
    let mut break_time = 1.0f32;
    let mut tool = String::from("hand");
    let mut rank = String::from("wood");
    let mut top = 3u8;
    let mut side = 3u8;
    let mut bottom = 3u8;
    let mut north: Option<u8> = None;
    let mut south: Option<u8> = None;
    let mut east: Option<u8> = None;
    let mut west: Option<u8> = None;

    for raw in text.lines() {
        let line = raw.trim().trim_start_matches('\u{feff}').trim();
        if line.is_empty() || line.starts_with('#') {
            continue;
        }
        if line.starts_with('[') {
            has_section = true;
            continue;
        }
        let sep = if line.contains(':') { ':' } else { '=' };
        let mut kv = line.splitn(2, sep);
        let k = kv.next().unwrap_or("").trim().to_lowercase();
        let v = kv.next().unwrap_or("").trim();
        match k.as_str() {
            "id" => key = v.to_string(),
            "name" => name = v.to_string(),
            "break_time" => {
                let digits: String = v
                    .trim_end_matches(|c: char| c.is_alphabetic())
                    .to_string();
                break_time = digits.parse().unwrap_or(1.0);
            }
            "tool" => tool = v.to_string(),
            "rank" => rank = v.to_string(),
            "top" => top = tex_for(v, root, tex, top),
            "side" => side = tex_for(v, root, tex, side),
            "bottom" => bottom = tex_for(v, root, tex, bottom),
            "north" => north = Some(tex_for(v, root, tex, north.unwrap_or(side))),
            "south" => south = Some(tex_for(v, root, tex, south.unwrap_or(side))),
            "east" => east = Some(tex_for(v, root, tex, east.unwrap_or(side))),
            "west" => west = Some(tex_for(v, root, tex, west.unwrap_or(side))),
            _ => {}
        }
    }

    if !has_section || (key.is_empty() && name.is_empty()) {
        return;
    }
    if key.is_empty() {
        key = name.to_lowercase().replace(' ', "_");
    }

    let id = match base_id(&key) {
        Some(i) => i,
        None => {
            let i = *next_id;
            *next_id = next_id.wrapping_add(1);
            i
        }
    };

    out.push(BlockDef {
        id,
        key: key.clone(),
        name: if name.is_empty() { key.clone() } else { name },
        break_time,
        tool,
        rank,
        tex_top: top,
        tex_side: side,
        tex_bottom: bottom,
        tex_north: north.unwrap_or(side),
        tex_south: south.unwrap_or(side),
        tex_east: east.unwrap_or(side),
        tex_west: west.unwrap_or(side),
        tinted: key == "grass",
    });
}

fn parse_color(v: &str) -> Option<[u8; 3]> {
    let parts: Vec<u8> = v.split(',').filter_map(|p| p.trim().parse().ok()).collect();
    if parts.len() >= 3 {
        Some([parts[0], parts[1], parts[2]])
    } else {
        None
    }
}

fn collect_dir(
    dir: &Path,
    root: &Path,
    list: &mut Vec<BlockDef>,
    next_id: &mut u8,
    tex: &mut Vec<ModTex>,
) {
    let rd = match std::fs::read_dir(dir) {
        Ok(d) => d,
        Err(_) => return,
    };
    let mut files: Vec<_> = rd.flatten().collect();
    files.sort_by_key(|e| e.file_name());
    for f in files {
        let p = f.path();
        let is_block_file = p.is_file() && p.file_name().map(|n| n != "mod.rs").unwrap_or(false);
        if is_block_file {
            let mut defs = Vec::new();
            parse_file(&p, root, &mut defs, next_id, tex);
            for d in defs {
                if !list.iter().any(|x| x.id == d.id) {
                    list.push(d);
                }
            }
        }
    }
}

fn push_mod_block(
    item: (String, String, Option<String>, [u8; 3]),
    root: &Path,
    blocks: &mut Vec<BlockDef>,
    next_id: &mut u8,
    tex: &mut Vec<ModTex>,
    count: &mut u32,
) {
    let (name, key, texture, color) = item;
    let mut key = key.trim().to_string();
    if key.is_empty() {
        key = name.trim().to_lowercase().replace(' ', "_");
    }
    if key.is_empty() || blocks.iter().any(|x| x.key == key) {
        return;
    }
    let row = match texture.as_deref() {
        Some(t) if !t.trim().is_empty() => tex_for(t, root, tex, 255),
        _ => 255,
    };
    let row = if row == 255 {
        let r = 6u8 + tex.len() as u8;
        if (r as usize) >= ATLAS_ROWS {
            return;
        }
        tex.push(ModTex { row: r, path: None, color });
        r
    } else {
        row
    };
    let id = *next_id;
    *next_id = next_id.wrapping_add(1);
    let name = if name.trim().is_empty() {
        String::from("block")
    } else {
        name.trim().to_string()
    };
    blocks.push(BlockDef {
        id,
        key,
        name,
        break_time: 1.0,
        tool: String::from("hand"),
        rank: String::from("wood"),
        tex_top: row,
        tex_side: row,
        tex_bottom: row,
        tex_north: row,
        tex_south: row,
        tex_east: row,
        tex_west: row,
        tinted: false,
    });
    *count += 1;
}

fn parse_mod_txt(
    root: &Path,
    blocks: &mut Vec<BlockDef>,
    next_id: &mut u8,
    tex: &mut Vec<ModTex>,
) -> Option<ModInfo> {
    let mut text = String::new();
    let mut found = false;
    for name in ["mod.json", "mod.txt"] {
        if let Ok(t) = std::fs::read_to_string(root.join(name)) {
            text.push_str(&t);
            text.push('\n');
            found = true;
        }
    }
    if !found {
        return None;
    }

    let mut info = ModInfo {
        name: String::new(),
        id: String::new(),
        desc: String::new(),
        ver: String::new(),
        blocks: 0,
        ids: Vec::new(),
    };
    let mut cur: Option<(String, String, Option<String>, [u8; 3])> = None;
    let mut in_block = false;

    for raw in text.lines() {
        let line = raw.trim().trim_start_matches('\u{feff}').trim();
        if line.is_empty() {
            continue;
        }
        if line.starts_with('[') {
            if let Some(item) = cur.take() {
                push_mod_block(item, root, blocks, next_id, tex, &mut info.blocks);
            }
            in_block = true;
            continue;
        }
        let stripped = line.trim_start_matches('#').trim();
        let sep = if stripped.contains('=') { '=' } else { ':' };
        let mut kv = stripped.splitn(2, sep);
        let k = kv
            .next()
            .unwrap_or("")
            .trim()
            .trim_matches('"')
            .trim_matches(',')
            .to_lowercase();
        let v = kv
            .next()
            .unwrap_or("")
            .trim()
            .trim_matches('"')
            .trim_end_matches(',')
            .to_string();

        if in_block {
            let item = cur.get_or_insert_with(|| (String::new(), String::new(), None, [200, 120, 220]));
            match k.as_str() {
                "name" => item.0 = v,
                "id" => item.1 = v,
                "texture" => item.2 = Some(v),
                "color" => {
                    if let Some(c) = parse_color(&v) {
                        item.3 = c;
                    }
                }
                _ => {}
            }
        } else {
            match k.as_str() {
                "mod_name" => info.name = v,
                "mod_id" => info.id = v,
                "mod_desc" => info.desc = v,
                "mod_ver" => info.ver = v,
                _ => {}
            }
        }
    }
    if let Some(item) = cur.take() {
        push_mod_block(item, root, blocks, next_id, tex, &mut info.blocks);
    }
    if info.name.is_empty() {
        info.name = root
            .file_name()
            .map(|n| n.to_string_lossy().to_string())
            .unwrap_or_default();
    }
    Some(info)
}

struct Registry {
    blocks: Vec<BlockDef>,
    mods: Vec<ModInfo>,
    tex: Vec<ModTex>,
}

fn build() -> Registry {
    let mut blocks: Vec<BlockDef> = Vec::new();
    let mut mods: Vec<ModInfo> = Vec::new();
    let mut tex: Vec<ModTex> = Vec::new();
    let mut next_id = 5u8;

    if let Some(bdir) = find_dir("blocks") {
        let broot = bdir
            .parent()
            .map(|p| p.to_path_buf())
            .unwrap_or_else(|| bdir.clone());
        collect_dir(&bdir, &broot, &mut blocks, &mut next_id, &mut tex);
    }

    if let Some(mdir) = find_dir("mods") {
        if let Ok(rd) = std::fs::read_dir(mdir) {
            let mut dirs: Vec<_> = rd.flatten().collect();
            dirs.sort_by_key(|e| e.file_name());
            for m in dirs {
                let root = m.path();
                if !root.is_dir() {
                    continue;
                }
                let before = blocks.len();
                collect_dir(&root.join("blocks"), &root, &mut blocks, &mut next_id, &mut tex);
                let dir_name = root
                    .file_name()
                    .map(|n| n.to_string_lossy().to_string())
                    .unwrap_or_default();
                let mut info = parse_mod_txt(&root, &mut blocks, &mut next_id, &mut tex).unwrap_or(ModInfo {
                    name: dir_name,
                    id: String::new(),
                    desc: String::new(),
                    ver: String::new(),
                    blocks: 0,
                    ids: Vec::new(),
                });
                info.ids = blocks[before..].iter().map(|b| b.id).collect();
                info.blocks = info.ids.len() as u32;
                mods.push(info);
            }
        }
    }

    blocks.sort_by_key(|d| d.id);
    Registry { blocks, mods, tex }
}

fn registry() -> &'static Registry {
    static REG: OnceLock<Registry> = OnceLock::new();
    REG.get_or_init(build)
}

pub fn all() -> &'static Vec<BlockDef> {
    &registry().blocks
}

pub fn mods() -> &'static Vec<ModInfo> {
    &registry().mods
}

pub fn mod_textures() -> &'static Vec<ModTex> {
    &registry().tex
}

pub fn find(id: u8) -> Option<&'static BlockDef> {
    all().iter().find(|d| d.id == id)
}

pub fn find_key(key: &str) -> Option<&'static BlockDef> {
    all().iter().find(|d| d.key == key)
}
