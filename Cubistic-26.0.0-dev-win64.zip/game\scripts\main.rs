mod world;

fn main() {
    let world = world::make_world(10);
    world::print_world(&world);
}
