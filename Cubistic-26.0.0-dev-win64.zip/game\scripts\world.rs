pub fn make_world(size: usize) -> Vec<Vec<char>> {
    vec![vec!['.'; size]; size]
}

pub fn print_world(world: &Vec<Vec<char>>) {
    for row in world {
        for cell in row {
            print!("{}", cell);
        }
        println!();
    }
}
